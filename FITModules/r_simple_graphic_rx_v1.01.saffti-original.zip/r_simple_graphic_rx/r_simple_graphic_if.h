/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2016-2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/**********************************************************************************************************************
* File Name    : r_simple_graphic_if.h
* Description  : Simple graphic driver header.
***********************************************************************************************************************
* History : DD.MM.YYYY Version Description
*         : 03.10.2017 1.00    Initial Release.
***********************************************************************************************************************/

#ifndef R_SIMPLE_GRAPHIC_IF_H
#define R_SIMPLE_GRAPHIC_IF_H

#include "platform.h"
#include "r_simple_glcdc_config_rx_config.h"
#include "r_simple_graphic_rx_config.h"

#define FONT_WIDTH SIMPLE_GRAPHIC_CFG_FONT_WIDTH
#define FONT_HEIGHT SIMPLE_GRAPHIC_CFG_FONT_HEIGHT
#define SCREEN_WIDTH XSIZE_PHYS
#define SCREEN_HEIGHT YSIZE_PHYS

#define REFRESH_FREQUENCY SIMPLE_GRAPHIC_CFG_REFRESH_FREQUENCY
#define ONE_LINE_INDEX R_SIMPLE_GLCDC_CFG_LINE_OFFSET

extern uint8_t* lcd_get_frame_buffer_pointer(void);

void R_SIMPLE_GRAPHIC_Open(void);
void R_SIMPLE_GRAPHIC_Close(void);
void R_SIMPLE_GRAPHIC_PutCharacter(char character);

#endif /* R_SIMPLE_GRAPHIC_IF_H */

