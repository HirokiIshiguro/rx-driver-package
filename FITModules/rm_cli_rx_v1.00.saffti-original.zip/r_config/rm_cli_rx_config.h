/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
#ifndef RM_CLI_RX_CONFIG_H
#define RM_CLI_RX_CONFIG_H

#define RM_CLI_CFG_DEFAULT_SCI_CHANNEL      (0u)
#define RM_CLI_CFG_DEFAULT_BAUD_RATE        (115200u)
#define RM_CLI_CFG_DEFAULT_INTERRUPT_PRIO   (5u)
#define RM_CLI_CFG_LINE_MAX                 (160u)
#define RM_CLI_CFG_ARG_MAX                  (8u)
#define RM_CLI_CFG_USER_COMMAND_MAX         (8u)
#define RM_CLI_CFG_BINARY_MAX               (1024u)
#define RM_CLI_CFG_PARAM_CHECKING_ENABLE    (1u)

#endif /* RM_CLI_RX_CONFIG_H */

