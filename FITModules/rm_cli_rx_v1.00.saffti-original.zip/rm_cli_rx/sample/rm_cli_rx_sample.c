/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
#include <stdint.h>

#include "rm_cli_rx_if.h"

static rm_cli_err_t sample_ping_command(rm_cli_ctrl_t * p_ctrl, int argc, char ** argv, void * p_context);

void rm_cli_rx_sample(void)
{
    static rm_cli_ctrl_t ctrl;
    rm_cli_cfg_t cfg;

    cfg.sci_channel = RM_CLI_CFG_DEFAULT_SCI_CHANNEL;
    cfg.baud_rate = RM_CLI_CFG_DEFAULT_BAUD_RATE;
    cfg.interrupt_priority = RM_CLI_CFG_DEFAULT_INTERRUPT_PRIO;
    cfg.echo = 1u;

    if (RM_CLI_SUCCESS != RM_CLI_Open(&ctrl, &cfg))
    {
        return;
    }

    (void) RM_CLI_RegisterCommand(&ctrl, "ping", sample_ping_command, "ping", NULL);

    while (1)
    {
        (void) RM_CLI_Process(&ctrl);
    }
}

static rm_cli_err_t sample_ping_command(rm_cli_ctrl_t * p_ctrl, int argc, char ** argv, void * p_context)
{
    (void) argc;
    (void) argv;
    (void) p_context;

    return RM_CLI_WriteString(p_ctrl, "pong\r\n");
}
