/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
#include <stdint.h>
#include <stddef.h>
#include <string.h>

#include "platform.h"
#include "rm_cli_rx_if.h"

static void rm_cli_sci_callback(void * p_args);
static rm_cli_err_t rm_cli_execute_line(rm_cli_ctrl_t * p_ctrl);
static rm_cli_err_t rm_cli_dispatch(rm_cli_ctrl_t * p_ctrl, int argc, char ** argv);
static int rm_cli_tokenize(char * p_line, char ** argv, int argv_max);
static rm_cli_err_t rm_cli_builtin_help(rm_cli_ctrl_t * p_ctrl, int argc, char ** argv, void * p_context);
static uint32_t rm_cli_strlen(char const * p_text);

static rm_cli_command_t const g_builtin_commands[] =
{
    { "help", rm_cli_builtin_help, "help", NULL },
};

rm_cli_err_t RM_CLI_Open(rm_cli_ctrl_t * p_ctrl, rm_cli_cfg_t const * p_cfg)
{
    sci_cfg_t sci_cfg;
    sci_err_t sci_err;
    uint8_t channel;

#if (RM_CLI_CFG_PARAM_CHECKING_ENABLE)
    if ((NULL == p_ctrl) || (NULL == p_cfg))
    {
        return RM_CLI_ERR_INVALID_ARGUMENT;
    }
#endif

    memset(p_ctrl, 0, sizeof(*p_ctrl));
    memset(&sci_cfg, 0, sizeof(sci_cfg));

    channel = (0u != p_cfg->sci_channel) ? p_cfg->sci_channel : RM_CLI_CFG_DEFAULT_SCI_CHANNEL;
    sci_cfg.async.baud_rate = (0u != p_cfg->baud_rate) ? p_cfg->baud_rate : RM_CLI_CFG_DEFAULT_BAUD_RATE;
    sci_cfg.async.clk_src = SCI_CLK_INT;
    sci_cfg.async.data_size = SCI_DATA_8BIT;
    sci_cfg.async.parity_en = SCI_PARITY_OFF;
    sci_cfg.async.parity_type = SCI_EVEN_PARITY;
    sci_cfg.async.stop_bits = SCI_STOPBITS_1;
    sci_cfg.async.int_priority = (0u != p_cfg->interrupt_priority) ? p_cfg->interrupt_priority :
                                  RM_CLI_CFG_DEFAULT_INTERRUPT_PRIO;

    sci_err = R_SCI_Open(channel, SCI_MODE_ASYNC, &sci_cfg, rm_cli_sci_callback, &p_ctrl->sci_handle);
    if (SCI_SUCCESS != sci_err)
    {
        return RM_CLI_ERR_SCI;
    }

    p_ctrl->opened = 1u;
    p_ctrl->echo = p_cfg->echo;

    (void) RM_CLI_WriteString(p_ctrl, "rm_cli_rx ready\r\n> ");
    return RM_CLI_SUCCESS;
}

rm_cli_err_t RM_CLI_Close(rm_cli_ctrl_t * p_ctrl)
{
#if (RM_CLI_CFG_PARAM_CHECKING_ENABLE)
    if (NULL == p_ctrl)
    {
        return RM_CLI_ERR_INVALID_ARGUMENT;
    }
#endif

    if (0u == p_ctrl->opened)
    {
        return RM_CLI_ERR_NOT_OPEN;
    }

    (void) R_SCI_Close(p_ctrl->sci_handle);
    memset(p_ctrl, 0, sizeof(*p_ctrl));
    return RM_CLI_SUCCESS;
}

rm_cli_err_t RM_CLI_Process(rm_cli_ctrl_t * p_ctrl)
{
    uint16_t available = 0u;
    uint8_t ch;

    if ((NULL == p_ctrl) || (0u == p_ctrl->opened))
    {
        return RM_CLI_ERR_NOT_OPEN;
    }

    if (SCI_SUCCESS != R_SCI_Control(p_ctrl->sci_handle, SCI_CMD_RX_Q_BYTES_AVAIL_TO_READ, &available))
    {
        return RM_CLI_ERR_SCI;
    }

    while (available > 0u)
    {
        if (SCI_SUCCESS != R_SCI_Receive(p_ctrl->sci_handle, &ch, 1u))
        {
            return RM_CLI_ERR_SCI;
        }

        if ((uint8_t) '\r' == ch || (uint8_t) '\n' == ch)
        {
            if (p_ctrl->line_length > 0u)
            {
                p_ctrl->line[p_ctrl->line_length] = '\0';
                (void) RM_CLI_WriteString(p_ctrl, "\r\n");
                (void) rm_cli_execute_line(p_ctrl);
                p_ctrl->line_length = 0u;
            }
            (void) RM_CLI_WriteString(p_ctrl, "> ");
        }
        else if (((uint8_t) '\b' == ch) || (0x7fu == ch))
        {
            if (p_ctrl->line_length > 0u)
            {
                p_ctrl->line_length--;
                if (0u != p_ctrl->echo)
                {
                    (void) RM_CLI_WriteString(p_ctrl, "\b \b");
                }
            }
        }
        else if (p_ctrl->line_length < (RM_CLI_CFG_LINE_MAX - 1u))
        {
            p_ctrl->line[p_ctrl->line_length++] = (char) ch;
            if (0u != p_ctrl->echo)
            {
                (void) R_SCI_Send(p_ctrl->sci_handle, &ch, 1u);
            }
        }
        else
        {
            p_ctrl->line_length = 0u;
            (void) RM_CLI_WriteString(p_ctrl, "\r\nERR line too long\r\n> ");
        }

        available--;
    }

    return RM_CLI_SUCCESS;
}

rm_cli_err_t RM_CLI_RegisterCommand(rm_cli_ctrl_t * p_ctrl,
                                    char const * p_name,
                                    rm_cli_command_handler_t p_handler,
                                    char const * p_help,
                                    void * p_context)
{
#if (RM_CLI_CFG_PARAM_CHECKING_ENABLE)
    if ((NULL == p_ctrl) || (NULL == p_name) || (NULL == p_handler))
    {
        return RM_CLI_ERR_INVALID_ARGUMENT;
    }
#endif

    if (0u == p_ctrl->opened)
    {
        return RM_CLI_ERR_NOT_OPEN;
    }

    if (p_ctrl->user_command_count >= RM_CLI_CFG_USER_COMMAND_MAX)
    {
        return RM_CLI_ERR_NO_SPACE;
    }

    p_ctrl->user_commands[p_ctrl->user_command_count].p_name = p_name;
    p_ctrl->user_commands[p_ctrl->user_command_count].p_handler = p_handler;
    p_ctrl->user_commands[p_ctrl->user_command_count].p_help = p_help;
    p_ctrl->user_commands[p_ctrl->user_command_count].p_context = p_context;
    p_ctrl->user_command_count++;
    return RM_CLI_SUCCESS;
}

rm_cli_err_t RM_CLI_WriteString(rm_cli_ctrl_t * p_ctrl, char const * p_text)
{
    uint32_t length;

    if ((NULL == p_ctrl) || (NULL == p_text) || (0u == p_ctrl->opened))
    {
        return RM_CLI_ERR_INVALID_ARGUMENT;
    }

    length = rm_cli_strlen(p_text);
    if (0u == length)
    {
        return RM_CLI_SUCCESS;
    }

    while (SCI_SUCCESS != R_SCI_Send(p_ctrl->sci_handle, (uint8_t *) p_text, (uint16_t) length))
    {
        R_BSP_SoftwareDelay(1u, BSP_DELAY_MILLISECS);
    }
    R_BSP_SoftwareDelay(2u, BSP_DELAY_MILLISECS);
    return RM_CLI_SUCCESS;
}

uint32_t RM_CLI_GetVersion(void)
{
    return (RM_CLI_RX_VERSION_MAJOR << 16) | RM_CLI_RX_VERSION_MINOR;
}

static void rm_cli_sci_callback(void * p_args)
{
    (void) p_args;
}

static rm_cli_err_t rm_cli_execute_line(rm_cli_ctrl_t * p_ctrl)
{
    char * argv[RM_CLI_CFG_ARG_MAX];
    int argc = rm_cli_tokenize(p_ctrl->line, argv, RM_CLI_CFG_ARG_MAX);
    rm_cli_err_t err;

    if (0 == argc)
    {
        return RM_CLI_SUCCESS;
    }

    err = rm_cli_dispatch(p_ctrl, argc, argv);
    if (RM_CLI_SUCCESS != err)
    {
        (void) RM_CLI_WriteString(p_ctrl, "ERR\r\n");
    }
    return err;
}

static rm_cli_err_t rm_cli_dispatch(rm_cli_ctrl_t * p_ctrl, int argc, char ** argv)
{
    uint32_t i;
    for (i = 0u; i < (uint32_t) (sizeof(g_builtin_commands) / sizeof(g_builtin_commands[0])); i++)
    {
        if (0 == strcmp(argv[0], g_builtin_commands[i].p_name))
        {
            return g_builtin_commands[i].p_handler(p_ctrl, argc, argv, g_builtin_commands[i].p_context);
        }
    }

    for (i = 0u; i < p_ctrl->user_command_count; i++)
    {
        if (0 == strcmp(argv[0], p_ctrl->user_commands[i].p_name))
        {
            return p_ctrl->user_commands[i].p_handler(p_ctrl,
                                                      argc,
                                                      argv,
                                                      p_ctrl->user_commands[i].p_context);
        }
    }

    (void) RM_CLI_WriteString(p_ctrl, "ERR unknown command\r\n");
    return RM_CLI_ERR_UNKNOWN_COMMAND;
}

static int rm_cli_tokenize(char * p_line, char ** argv, int argv_max)
{
    int argc = 0;
    char * p = p_line;

    while ((*p != '\0') && (argc < argv_max))
    {
        while ((*p == ' ') || (*p == '\t'))
        {
            p++;
        }
        if ('\0' == *p)
        {
            break;
        }
        argv[argc++] = p;
        while ((*p != '\0') && (*p != ' ') && (*p != '\t'))
        {
            p++;
        }
        if ('\0' != *p)
        {
            *p++ = '\0';
        }
    }
    return argc;
}

static rm_cli_err_t rm_cli_builtin_help(rm_cli_ctrl_t * p_ctrl, int argc, char ** argv, void * p_context)
{
    uint32_t i;
    (void) argc;
    (void) argv;
    (void) p_context;

    for (i = 0u; i < (uint32_t) (sizeof(g_builtin_commands) / sizeof(g_builtin_commands[0])); i++)
    {
        (void) RM_CLI_WriteString(p_ctrl, g_builtin_commands[i].p_help);
        (void) RM_CLI_WriteString(p_ctrl, "\r\n");
    }
    for (i = 0u; i < p_ctrl->user_command_count; i++)
    {
        (void) RM_CLI_WriteString(p_ctrl, (NULL != p_ctrl->user_commands[i].p_help) ?
                                  p_ctrl->user_commands[i].p_help : p_ctrl->user_commands[i].p_name);
        (void) RM_CLI_WriteString(p_ctrl, "\r\n");
    }
    return RM_CLI_SUCCESS;
}

static uint32_t rm_cli_strlen(char const * p_text)
{
    uint32_t length = 0u;
    while ((NULL != p_text) && ('\0' != p_text[length]))
    {
        length++;
    }
    return length;
}
