# rm_cli_rx

Renesas RX の `r_sci_rx` UART モード上で動く小さな CLI FIT ミドルウェアです。
ストレージやプロビジョニング処理は内蔵せず、アプリケーションが `RM_CLI_RegisterCommand()` で
必要なコマンドを登録します。
