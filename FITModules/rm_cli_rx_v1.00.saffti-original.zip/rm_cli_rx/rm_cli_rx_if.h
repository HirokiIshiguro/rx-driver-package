/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
#ifndef RM_CLI_RX_IF_H
#define RM_CLI_RX_IF_H

#include <stdint.h>
#include "r_sci_rx_if.h"
#include "rm_cli_rx_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RM_CLI_RX_VERSION_MAJOR        (1u)
#define RM_CLI_RX_VERSION_MINOR        (0u)

typedef enum e_rm_cli_err
{
    RM_CLI_SUCCESS = 0,
    RM_CLI_ERR_INVALID_ARGUMENT,
    RM_CLI_ERR_SCI,
    RM_CLI_ERR_NOT_OPEN,
    RM_CLI_ERR_NO_SPACE,
    RM_CLI_ERR_UNKNOWN_COMMAND,
    RM_CLI_ERR_COMMAND_FAILED
} rm_cli_err_t;

typedef struct st_rm_cli_ctrl rm_cli_ctrl_t;
typedef rm_cli_err_t (* rm_cli_command_handler_t)(rm_cli_ctrl_t * p_ctrl,
                                                  int argc,
                                                  char ** argv,
                                                  void * p_context);

typedef struct st_rm_cli_command
{
    char const * p_name;
    rm_cli_command_handler_t p_handler;
    char const * p_help;
    void * p_context;
} rm_cli_command_t;

typedef struct st_rm_cli_cfg
{
    uint8_t sci_channel;
    uint32_t baud_rate;
    uint8_t interrupt_priority;
    uint32_t echo;
} rm_cli_cfg_t;

struct st_rm_cli_ctrl
{
    sci_hdl_t sci_handle;
    uint32_t opened;
    uint32_t echo;
    char line[RM_CLI_CFG_LINE_MAX];
    uint32_t line_length;
    rm_cli_command_t user_commands[RM_CLI_CFG_USER_COMMAND_MAX];
    uint32_t user_command_count;
};

rm_cli_err_t RM_CLI_Open(rm_cli_ctrl_t * p_ctrl, rm_cli_cfg_t const * p_cfg);
rm_cli_err_t RM_CLI_Close(rm_cli_ctrl_t * p_ctrl);
rm_cli_err_t RM_CLI_Process(rm_cli_ctrl_t * p_ctrl);
rm_cli_err_t RM_CLI_RegisterCommand(rm_cli_ctrl_t * p_ctrl,
                                    char const * p_name,
                                    rm_cli_command_handler_t p_handler,
                                    char const * p_help,
                                    void * p_context);
rm_cli_err_t RM_CLI_WriteString(rm_cli_ctrl_t * p_ctrl, char const * p_text);
uint32_t RM_CLI_GetVersion(void);

#ifdef __cplusplus
}
#endif

#endif /* RM_CLI_RX_IF_H */
