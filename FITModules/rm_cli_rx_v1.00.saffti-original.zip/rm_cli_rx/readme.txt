rm_cli_rx: small UART CLI middleware for Renesas RX.

