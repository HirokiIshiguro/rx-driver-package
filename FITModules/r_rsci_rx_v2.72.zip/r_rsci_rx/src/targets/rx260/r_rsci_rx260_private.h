/***********************************************************************************************************************
* Copyright (c) 2024 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_rsci_rx260_private.h
* Description  : Functions for using RSCI on the RX260 device.
************************************************************************************************************************
* History : DD.MM.YYYY Version Description
*           28.06.2024 1.00    Initial Release
*           15.03.2025 2.71    Updated disclaimer
***********************************************************************************************************************/

#ifndef RSCI_RX260_H
#define RSCI_RX260_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "../../r_rsci_rx_private.h"

#if (RSCI_CFG_ASYNC_INCLUDED || RSCI_CFG_MANC_INCLUDED)
#include "r_byteq_if.h"
#endif

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/* RSCI channel include Check */
#if ((RSCI_CFG_CH10_INCLUDED != 0) || (RSCI_CFG_CH11_INCLUDED != 0) \
    || ((RSCI_CFG_CH0_INCLUDED != 0) && (((BSP_PACKAGE_PINS == 48) || (BSP_PACKAGE_PINS == 64)))) \
    || ((RSCI_CFG_CH9_INCLUDED != 0) && (BSP_PACKAGE_PINS == 48)))
    #error "ERROR - Unsupported channel chosen in r_rsci_config.h"
#endif

/* RSCI SCR register masks */
#define RSCI_SCR0_TIE_MASK    (0x00100000U)     /* transmit interrupt enable */
#define RSCI_SCR0_RIE_MASK    (0x00010000U)     /* receive interrupt enable */
#define RSCI_SCR0_TE_MASK     (0x00000010U)     /* transmitter enable */
#define RSCI_SCR0_RE_MASK     (0x00000001U)     /* receiver enable */
#define RSCI_EN_XCVR_MASK     (RSCI_SCR0_RE_MASK | RSCI_SCR0_TE_MASK | RSCI_SCR0_RIE_MASK | RSCI_SCR0_TIE_MASK)

/* RSCI MMCR register masks */
#define RSCI_MMCR_PFERIE_MASK    (0x01000000U)     /* preface error interrupt enable */
#define RSCI_MMCR_SYERIE_MASK    (0x02000000U)     /* sync error interrupt enable */
#define RSCI_MMCR_SBERIE_MASK    (0x04000000U)     /* transmitter enable */
#define RSCI_EN_MMCR_ERR_MASK    (RSCI_MMCR_PFERIE_MASK | RSCI_MMCR_SYERIE_MASK | RSCI_MMCR_SBERIE_MASK )

/* RSCI SSR register receiver error masks */
#define RSCI_SSR_ORER_MASK         (0x01000000U)     /* overflow error */
#define RSCI_SSR_AFER_MASK         (0x10000000U)     /* framing error */
#define RSCI_SSR_APER_MASK         (0x08000000U)     /* parity err */
#define RSCI_RCVR_ERR_MASK         (RSCI_SSR_ORER_MASK | RSCI_SSR_AFER_MASK | RSCI_SSR_APER_MASK)

/* RSCI SSCR register receiver error masks */
#define RSCI_SSCR_ORERC_MASK        (0x01000000U)     /* overflow error */
#define RSCI_SSCR_AFERC_MASK        (0x10000000U)     /* framing error */
#define RSCI_SSCR_APERC_MASK        (0x08000000U)     /* parity err */
#define RSCI_SSCR_ERR_CLEAR_MASK    (RSCI_SSCR_ORERC_MASK | RSCI_SSCR_AFERC_MASK | RSCI_SSCR_APERC_MASK)

/* RSCI MMSR register receiver error masks */
#define RSCI_MMSR_PFER_MASK        (0x00000001U)     /* preface error */
#define RSCI_MMSR_SYER_MASK        (0X00000002U)     /* sync error */
#define RSCI_MMSR_SBER_MASK        (0x00000004U)     /* start bit error */
#define RSCI_MMSR_MCER_MASK        (0x00000010U)     /* manchester code error */
#define RSCI_MMSR_ERR_MASK         (RSCI_MMSR_PFER_MASK | RSCI_MMSR_SYER_MASK \
                                    | RSCI_MMSR_SBER_MASK | RSCI_MMSR_MCER_MASK)

/* RSCI MMSCR register receiver error clear masks */
#define RSCI_MMSCR_PFERC_MASK      (0x00000001U)     /* preface error clear */
#define RSCI_MMSCR_SYERC_MASK      (0X00000002U)     /* sync error clear */
#define RSCI_MMSCR_SBERC_MASK      (0x00000004U)     /* start bit error clear */
#define RSCI_MMSCR_MCERC_MASK      (0x00000010U)     /* manchester code error clear */
#define RSCI_MMSCR_ERR_CLEAR_MASK  (RSCI_MMSCR_PFERC_MASK | RSCI_MMSCR_SYERC_MASK \
                                    | RSCI_MMSCR_SBERC_MASK | RSCI_MMSCR_MCERC_MASK)

/* Macros to enable and disable ICU interrupts */
#define ENABLE_RXI_INT      (R_BSP_BIT_SET(hdl->rom->icu_rxi, hdl->rom->rxi_bit_num))
#define DISABLE_RXI_INT     (R_BSP_BIT_CLEAR(hdl->rom->icu_rxi, hdl->rom->rxi_bit_num))
#define ENABLE_TXI_INT      (R_BSP_BIT_SET(hdl->rom->icu_txi, hdl->rom->txi_bit_num))
#define DISABLE_TXI_INT     (R_BSP_BIT_CLEAR(hdl->rom->icu_txi, hdl->rom->txi_bit_num))

#define ENABLE_ERI_INT      (R_BSP_BIT_SET(hdl->rom->icu_eri, hdl->rom->eri_bit_num))
#define DISABLE_ERI_INT     (R_BSP_BIT_CLEAR(hdl->rom->icu_eri, hdl->rom->eri_bit_num))
#define ENABLE_TEI_INT      (R_BSP_BIT_SET(hdl->rom->icu_tei, hdl->rom->tei_bit_num))
#define DISABLE_TEI_INT     (R_BSP_BIT_CLEAR(hdl->rom->icu_tei, hdl->rom->tei_bit_num))

#define NUM_DIVISORS_ASYNC  (10)
#define NUM_DIVISORS_SYNC   (4)

/*****************************************************************************
Typedef definitions
******************************************************************************/

/* ROM INFO */

typedef struct st_rsci_ch_rom    /* RSCI ROM info for channel control block */
{
    volatile  struct st_rsci9 R_BSP_EVENACCESS_SFR  *regs;  /* base ptr to ch registers */
    volatile  uint32_t R_BSP_EVENACCESS_SFR *mstp;          /* ptr to mstp register */
    uint32_t                        stop_mask;      /* mstp mask to disable ch */
    volatile  uint8_t R_BSP_EVENACCESS_SFR  *ipr;           /* ptr to IPR register */
    volatile  uint8_t R_BSP_EVENACCESS_SFR  *ir_rxi;        /* ptr to RXI IR register */
    volatile  uint8_t R_BSP_EVENACCESS_SFR  *ir_txi;        /* ptr to TXI IR register */
    volatile  uint8_t R_BSP_EVENACCESS_SFR  *ir_tei;        /* ptr to TEI IR register */
    volatile  uint8_t R_BSP_EVENACCESS_SFR  *ir_eri;        /* ptr to ERI IR register */

    /* 
    * DO NOT use the enable/disable interrupt bits in the SCR 
    * register. Pending interrupts can be lost that way.
    */
    volatile  uint8_t R_BSP_EVENACCESS_SFR  *icu_rxi;       /* ptr to ICU register */
    volatile  uint8_t R_BSP_EVENACCESS_SFR  *icu_txi;
    volatile  uint8_t R_BSP_EVENACCESS_SFR  *icu_tei;
    volatile  uint8_t R_BSP_EVENACCESS_SFR  *icu_eri;
    uint8_t                         eri_bit_num;    /* ICU enable/disable eri bit number */
    uint8_t                         rxi_bit_num;    /* ICU enable/disable rxi bit number */
    uint8_t                         txi_bit_num;    /* ICU enable/disable txi bit number */
    uint8_t                         tei_bit_num;    /* ICU enable/disable tei bit number */
    uint8_t                         chan;           /* Channel RSCI is used*/
} rsci_ch_rom_t;


/* CHANNEL CONTROL BLOCK */

typedef struct st_rsci_ch_ctrl       /* RSCI channel control (for handle) */
{
    rsci_ch_rom_t const *rom;        /* pointer to rom info */
    rsci_mode_t      mode;           /* operational mode */
    uint32_t        baud_rate;      /* baud rate */
    void          (*callback)(void *p_args); /* function ptr for rcvr errs */
    union
    {
#if (RSCI_CFG_ASYNC_INCLUDED || RSCI_CFG_MANC_INCLUDED)
        byteq_hdl_t     que;        /* async/manc transmit queue handle */
#endif
        uint8_t         *buf;       /* sspi/sync tx buffer ptr */
    } u_tx_data;
    union
    {
#if (RSCI_CFG_ASYNC_INCLUDED || RSCI_CFG_MANC_INCLUDED)
        byteq_hdl_t     que;        /* async/manc receive queue handle */
#endif
        uint8_t         *buf;       /* sspi/sync rx buffer ptr */
    } u_rx_data;
    bool            tx_idle;        /* TDR is empty (async); TSR is empty (sync/sspi) */
#if (RSCI_CFG_SSPI_INCLUDED || RSCI_CFG_SYNC_INCLUDED)
    bool            save_rx_data;   /* save the data that is clocked in */
    uint16_t        tx_cnt;         /* number of bytes to transmit */
    uint16_t        rx_cnt;         /* number of bytes to receive */
    bool            tx_dummy;       /* transmit dummy byte, not buffer */
#endif
    uint32_t        pclk_speed;     /* saved peripheral clock speed for break generation */
#if RSCI_CFG_MANC_INCLUDED
    uint8_t         rx_decoding_pol;    /* Decoding conversion select */
    uint8_t         rx_preface_length;  /* RX Preface length */
    uint8_t         rx_preface_pattern; /* RX Preface pattern */
    uint8_t         tx_encoding_pol;    /* Encoding conversion select */
    uint8_t         tx_preface_length;  /* TX Preface length */
    uint8_t         tx_preface_pattern; /* TX Preface pattern */
#endif
} rsci_ch_ctrl_t;


/* BAUD DIVISOR INFO */

/* BRR = (PCLK/(divisor * baud)) - 1 */
/* when abcs=1, divisor = 32*pow(2,2n-1) */
/* when abcs=0, divisor = 64*pow(2,2n-1) */

typedef struct st_baud_divisor
{
    int16_t     divisor;    // clock divisor
    uint8_t     abcs;       // abcs value to get divisor
    uint8_t     bgdm;       // bdgm value to get divisor
    uint8_t     abcse;      // abcse value to get divisor
    uint8_t     cks;        // cks  value to get divisor (cks = n)
} baud_divisor_t;



/*****************************************************************************
Exported global variables and functions
******************************************************************************/
extern const rsci_hdl_t g_rsci_handles[];

#if (RSCI_CFG_ASYNC_INCLUDED || RSCI_CFG_MANC_INCLUDED)
extern const baud_divisor_t rsci_async_baud[];
#endif
#if (RSCI_CFG_SSPI_INCLUDED || RSCI_CFG_SYNC_INCLUDED)
extern const baud_divisor_t rsci_sync_baud[];
#endif


#if (RSCI_CFG_CH0_INCLUDED)
extern const rsci_ch_rom_t      g_rsci_ch0_rom;
extern rsci_ch_ctrl_t           g_rsci_ch0_ctrl;
#endif

#if (RSCI_CFG_CH8_INCLUDED)
extern const rsci_ch_rom_t      g_rsci_ch8_rom;
extern rsci_ch_ctrl_t           g_rsci_ch8_ctrl;
#endif

#if (RSCI_CFG_CH9_INCLUDED)
extern const rsci_ch_rom_t      g_rsci_ch9_rom;
extern rsci_ch_ctrl_t           g_rsci_ch9_ctrl;
#endif

/*****************************************************************************
Exported global functions
******************************************************************************/
extern void rsci_init_register (rsci_hdl_t const hdl);

#if (RSCI_CFG_ASYNC_INCLUDED)
extern rsci_err_t rsci_async_cmds (rsci_hdl_t const hdl,
                                rsci_cmd_t const cmd,
                                void            *p_args);
#endif

#if (RSCI_CFG_SSPI_INCLUDED || RSCI_CFG_SYNC_INCLUDED)
extern rsci_err_t rsci_sync_cmds (rsci_hdl_t const hdl,
                                rsci_cmd_t const cmd,
                                void            *p_args);
#endif

#if (RSCI_CFG_MANC_INCLUDED)
extern rsci_err_t rsci_manc_cmds (rsci_hdl_t const hdl,
                                rsci_cmd_t const cmd,
                                void            *p_args);
#endif

extern rsci_err_t rsci_mcu_param_check (uint8_t const chan);

extern int32_t rsci_init_bit_rate (rsci_hdl_t const    hdl,
                                uint32_t const     pclk,
                                uint32_t const     baud);

extern void rsci_initialize_ints (rsci_hdl_t const hdl,
                                uint8_t const   priority);

extern void rsci_disable_ints (rsci_hdl_t const hdl);

#endif /* RSCI_RX260_H */

