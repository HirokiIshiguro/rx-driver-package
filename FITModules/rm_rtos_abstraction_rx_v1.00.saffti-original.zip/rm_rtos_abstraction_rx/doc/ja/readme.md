# rm_rtos_abstraction_rx

Renesas RX 向けの小さな RTOS 抽象化 FIT ミドルウェアです。

`RM_RTOS_ABSTRACTION_SleepTask(task_id)` は、アプリケーションが登録した sleep hook を呼び出します。
未登録の場合は `r_bsp` の `BSP_CFG_RTOS_USED` に従って動作します。

- `0`: RTOS なし。成功扱いの no-op として戻ります。
- `0` 以外: RTOS 使用中。`RM_RTOS_ABSTRACTION_ERR_NOT_CONFIGURED` を返し、RTOS binding の設定漏れを検出できるようにします。

`RM_RTOS_ABSTRACTION_GetRtosUsed()` で現在の `BSP_CFG_RTOS_USED` 値を取得できます。
