# rm_rtos_abstraction_rx

`rm_rtos_abstraction_rx` provides RTOS-neutral middleware hooks for Renesas RX projects.

`RM_RTOS_ABSTRACTION_SleepTask(task_id)` calls the application-registered sleep hook when one is registered. If no hook
is registered, the behavior is selected from `BSP_CFG_RTOS_USED`:

- `0`: no RTOS, return success as a no-op.
- non-zero: RTOS is used, return `RM_RTOS_ABSTRACTION_ERR_NOT_CONFIGURED`.

Use `RM_RTOS_ABSTRACTION_GetRtosUsed()` to read the active `BSP_CFG_RTOS_USED` value.
