/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_ssd1306_rx_config.h
* Description  : Configuration for r_ssd1306_rx FIT module
***********************************************************************************************************************/
#ifndef R_SSD1306_RX_CONFIG_H
#define R_SSD1306_RX_CONFIG_H

/* SPECIFY WHETHER TO INCLUDE CODE FOR API PARAMETER CHECKING */
/* Setting to BSP_CFG_PARAM_CHECKING_ENABLE utilizes the system default setting */
/* Setting to 1 includes parameter checking; 0 compiles out parameter checking */
#define SSD1306_CFG_PARAM_CHECKING_ENABLE   (BSP_CFG_PARAM_CHECKING_ENABLE)

/* I2C bus backend:
 *   0 = r_riic_rx    (RIIC peripheral, supports up to Fast Mode Plus 1 MHz)
 *   1 = r_sci_iic_rx (SCI simple-I2C, up to 384 kHz)
 */
#define SSD1306_CFG_I2C_BACKEND             (0)

/* I2C channel number (RIIC channel when backend=0, SCI channel when backend=1) */
#define SSD1306_CFG_I2C_CHANNEL             (0)

/* SSD1306 7-bit I2C slave address (depends on SA0 strap on the panel) */
#define SSD1306_CFG_SLAVE_ADDR              (0x3C)

/* Display geometry */
#define SSD1306_CFG_WIDTH                   (128)
#define SSD1306_CFG_HEIGHT                  (64)

/* Rotate 180 degrees at init time (segment + COM remap) */
#define SSD1306_CFG_ROTATE_180              (1)

/* Include graphics primitive helpers (R_SSD1306_Gfx_*) */
#define SSD1306_CFG_ENABLE_GFX              (1)

/* Include fixed-rate frame scheduler (R_SSD1306_FrameSched_*) */
#define SSD1306_CFG_ENABLE_FRAME_SCHED      (1)

/* Busy-wait iteration budget used while polling the I2C completion callback */
#define SSD1306_CFG_I2C_TIMEOUT_COUNT       (1000000UL)

#endif /* R_SSD1306_RX_CONFIG_H */
