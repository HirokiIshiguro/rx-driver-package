/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_ssd1306_rx_if.h
* Description  : Public interface for the r_ssd1306_rx FIT module (SSD1306 128x64 OLED over I2C).
************************************************************************************************************************
* History : DD.MM.YYYY Version Description
*         : 13.04.2026 1.00    Initial release (ported from 128_64_display_badapple reference code).
***********************************************************************************************************************/
#ifndef R_SSD1306_RX_IF_H
#define R_SSD1306_RX_IF_H

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "platform.h"
#include "r_ssd1306_rx_config.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define SSD1306_VERSION_MAJOR       (1)
#define SSD1306_VERSION_MINOR       (0)

#define SSD1306_WIDTH               (SSD1306_CFG_WIDTH)
#define SSD1306_HEIGHT              (SSD1306_CFG_HEIGHT)
#define SSD1306_PAGES               (SSD1306_HEIGHT / 8)
#define SSD1306_BUF_SIZE            (SSD1306_WIDTH * SSD1306_PAGES)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef enum e_ssd1306_err
{
    SSD1306_SUCCESS = 0,
    SSD1306_ERR_NULL_PTR,
    SSD1306_ERR_INVALID_ARG,
    SSD1306_ERR_BUS,
    SSD1306_ERR_TIMEOUT,
    SSD1306_ERR_NOT_OPEN,
    SSD1306_ERR_UNSUPPORTED
} ssd1306_err_t;

typedef enum e_ssd1306_cmd
{
    SSD1306_CMD_CLEAR            = 0,  /* p_args unused */
    SSD1306_CMD_SET_PIXEL        = 1,  /* p_args: ssd1306_pixel_arg_t *   */
    SSD1306_CMD_FLUSH            = 2,  /* p_args unused (full framebuffer) */
    SSD1306_CMD_FLUSH_DIRTY      = 3,  /* p_args: int * (pages_sent, optional) */
    SSD1306_CMD_FLUSH_PAGES      = 4,  /* p_args: ssd1306_page_range_t *  */
    SSD1306_CMD_SEND_RAW_CMD     = 5,  /* p_args: uint8_t * (single byte) */
    SSD1306_CMD_GET_BUFFER       = 6,  /* p_args: uint8_t ** (out param)  */
    SSD1306_CMD_SET_INVERT       = 7,  /* p_args: uint8_t *  (0/1)        */
    SSD1306_CMD_SET_DISPLAY_ON   = 8   /* p_args: uint8_t *  (0/1)        */
} ssd1306_cmd_t;

typedef struct st_ssd1306_pixel_arg
{
    int16_t x;
    int16_t y;
    uint8_t on;
} ssd1306_pixel_arg_t;

typedef struct st_ssd1306_page_range
{
    int8_t page_start;  /* 0..SSD1306_PAGES-1 */
    int8_t page_end;    /* 0..SSD1306_PAGES-1, >= page_start */
} ssd1306_page_range_t;

typedef struct st_ssd1306_ctrl ssd1306_ctrl_t;
typedef ssd1306_ctrl_t * ssd1306_hdl_t;

/***********************************************************************************************************************
Public Functions
***********************************************************************************************************************/
ssd1306_err_t R_SSD1306_Open(ssd1306_hdl_t * const p_hdl);
ssd1306_err_t R_SSD1306_Close(ssd1306_hdl_t const hdl);
ssd1306_err_t R_SSD1306_Write(ssd1306_hdl_t const hdl);
ssd1306_err_t R_SSD1306_Control(ssd1306_hdl_t const hdl, ssd1306_cmd_t cmd, void * p_args);
uint32_t      R_SSD1306_GetVersion(void);

#if (SSD1306_CFG_ENABLE_GFX == 1)
/* Optional graphics helpers. All coordinates are signed so off-screen primitives
 * are safely clipped inside the module. Requires a successfully opened handle. */
void R_SSD1306_Gfx_Pixel(ssd1306_hdl_t const hdl, int16_t x, int16_t y, uint8_t on);
void R_SSD1306_Gfx_HLine(ssd1306_hdl_t const hdl, int16_t x, int16_t y, int16_t w, uint8_t on);
void R_SSD1306_Gfx_VLine(ssd1306_hdl_t const hdl, int16_t x, int16_t y, int16_t h, uint8_t on);
void R_SSD1306_Gfx_Line (ssd1306_hdl_t const hdl, int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint8_t on);
void R_SSD1306_Gfx_Rect (ssd1306_hdl_t const hdl, int16_t x, int16_t y, int16_t w, int16_t h, uint8_t on);
void R_SSD1306_Gfx_FillRect(ssd1306_hdl_t const hdl, int16_t x, int16_t y, int16_t w, int16_t h, uint8_t on);
void R_SSD1306_Gfx_Circle(ssd1306_hdl_t const hdl, int16_t cx, int16_t cy, int16_t r, uint8_t on);
int16_t R_SSD1306_Gfx_Putc(ssd1306_hdl_t const hdl, int16_t x, int16_t y, char c, uint8_t on);
int16_t R_SSD1306_Gfx_Puts(ssd1306_hdl_t const hdl, int16_t x, int16_t y, const char * s, uint8_t on);
#endif /* SSD1306_CFG_ENABLE_GFX */

#if (SSD1306_CFG_ENABLE_FRAME_SCHED == 1)
/* Fixed-rate frame scheduler backed by r_cmt_rx. Independent of any handle:
 * the scheduler simply increments a counter at the target fps. */
ssd1306_err_t R_SSD1306_FrameSched_Init(uint32_t fps);
void          R_SSD1306_FrameSched_Wait(void);
uint32_t      R_SSD1306_FrameSched_Frames(void);
uint32_t      R_SSD1306_FrameSched_Fps(void);
#endif /* SSD1306_CFG_ENABLE_FRAME_SCHED */

#endif /* R_SSD1306_RX_IF_H */
