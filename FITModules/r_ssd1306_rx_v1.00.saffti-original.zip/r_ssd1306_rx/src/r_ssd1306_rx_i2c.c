/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_ssd1306_rx_i2c.c
* Description  : I2C transport backend for r_ssd1306_rx (r_riic_rx or r_sci_iic_rx).
*                Blocking master-send pattern: queue via MasterSend API and wait
*                for the completion callback to raise the done flag.
***********************************************************************************************************************/
#include <string.h>
#include "r_ssd1306_rx_private.h"

static uint8_t          s_slv_addr;
static uint8_t          s_ctrl_byte;
static volatile uint8_t s_done;

#if (SSD1306_CFG_I2C_BACKEND == 0)
/*--------------------------------------------------------------------------
 *  RIIC backend (r_riic_rx)
 *--------------------------------------------------------------------------*/
#include "r_riic_rx_if.h"

static riic_info_t s_info;

static void riic_cb(void)
{
    s_done = 1;
}

ssd1306_err_t r_ssd1306_rx_i2c_open(uint8_t slv_addr7)
{
    riic_return_t ret;
    s_slv_addr = slv_addr7;

    memset((void *)&s_info, 0, sizeof(s_info));
    s_info.ch_no        = (uint8_t)SSD1306_CFG_I2C_CHANNEL;
    s_info.dev_sts      = RIIC_NO_INIT;
    s_info.callbackfunc = riic_cb;

    ret = R_RIIC_Open(&s_info);
    return (ret == RIIC_SUCCESS) ? SSD1306_SUCCESS : SSD1306_ERR_BUS;
}

ssd1306_err_t r_ssd1306_rx_i2c_send(uint8_t ctrl_byte, const uint8_t * data, uint32_t len)
{
    uint8_t slv = s_slv_addr;
    riic_return_t ret;
    volatile uint32_t to = (uint32_t)SSD1306_CFG_I2C_TIMEOUT_COUNT;

    s_ctrl_byte = ctrl_byte;
    s_info.p_slv_adr = &slv;
    s_info.p_data1st = &s_ctrl_byte;
    s_info.cnt1st    = 1;
    s_info.p_data2nd = (uint8_t *)data;
    s_info.cnt2nd    = len;

    s_done = 0;
    ret = R_RIIC_MasterSend(&s_info);
    if (ret != RIIC_SUCCESS) return SSD1306_ERR_BUS;

    while (!s_done && --to) { }
    return s_done ? SSD1306_SUCCESS : SSD1306_ERR_TIMEOUT;
}

ssd1306_err_t r_ssd1306_rx_i2c_close(void)
{
    (void)R_RIIC_Close(&s_info);
    return SSD1306_SUCCESS;
}

#elif (SSD1306_CFG_I2C_BACKEND == 1)
/*--------------------------------------------------------------------------
 *  SCI simple-I2C backend (r_sci_iic_rx)
 *--------------------------------------------------------------------------*/
#include "r_sci_iic_rx_if.h"

static sci_iic_info_t s_info;

static void sci_iic_cb(void)
{
    s_done = 1;
}

ssd1306_err_t r_ssd1306_rx_i2c_open(uint8_t slv_addr7)
{
    sci_iic_return_t ret;
    s_slv_addr = slv_addr7;

    memset((void *)&s_info, 0, sizeof(s_info));
    s_info.ch_no        = (uint8_t)SSD1306_CFG_I2C_CHANNEL;
    s_info.dev_sts      = SCI_IIC_NO_INIT;
    s_info.callbackfunc = sci_iic_cb;

    ret = R_SCI_IIC_Open(&s_info);
    return (ret == SCI_IIC_SUCCESS) ? SSD1306_SUCCESS : SSD1306_ERR_BUS;
}

ssd1306_err_t r_ssd1306_rx_i2c_send(uint8_t ctrl_byte, const uint8_t * data, uint32_t len)
{
    uint8_t slv = s_slv_addr;
    sci_iic_return_t ret;
    volatile uint32_t to = (uint32_t)SSD1306_CFG_I2C_TIMEOUT_COUNT;

    s_ctrl_byte = ctrl_byte;
    s_info.p_slv_adr = &slv;
    s_info.p_data1st = &s_ctrl_byte;
    s_info.cnt1st    = 1;
    s_info.p_data2nd = (uint8_t *)data;
    s_info.cnt2nd    = len;

    s_done = 0;
    ret = R_SCI_IIC_MasterSend(&s_info);
    if (ret != SCI_IIC_SUCCESS) return SSD1306_ERR_BUS;

    while (!s_done && --to) { }
    return s_done ? SSD1306_SUCCESS : SSD1306_ERR_TIMEOUT;
}

ssd1306_err_t r_ssd1306_rx_i2c_close(void)
{
    (void)R_SCI_IIC_Close(&s_info);
    return SSD1306_SUCCESS;
}

#else
#error "SSD1306_CFG_I2C_BACKEND must be 0 (r_riic_rx) or 1 (r_sci_iic_rx)"
#endif
