/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_ssd1306_rx_gfx.c
* Description  : Lightweight graphics primitive library for the SSD1306 framebuffer.
***********************************************************************************************************************/
#include "r_ssd1306_rx_private.h"

#if (SSD1306_CFG_ENABLE_GFX == 1)

static void set_pixel(ssd1306_hdl_t const hdl, int16_t x, int16_t y, uint8_t on)
{
    ssd1306_pixel_arg_t a;
    a.x = x;
    a.y = y;
    a.on = on;
    (void)R_SSD1306_Control(hdl, SSD1306_CMD_SET_PIXEL, &a);
}

void R_SSD1306_Gfx_Pixel(ssd1306_hdl_t const hdl, int16_t x, int16_t y, uint8_t on)
{
    set_pixel(hdl, x, y, on);
}

void R_SSD1306_Gfx_HLine(ssd1306_hdl_t const hdl, int16_t x, int16_t y, int16_t w, uint8_t on)
{
    int16_t i;
    for (i = 0; i < w; i++)
    {
        set_pixel(hdl, (int16_t)(x + i), y, on);
    }
}

void R_SSD1306_Gfx_VLine(ssd1306_hdl_t const hdl, int16_t x, int16_t y, int16_t h, uint8_t on)
{
    int16_t i;
    for (i = 0; i < h; i++)
    {
        set_pixel(hdl, x, (int16_t)(y + i), on);
    }
}

void R_SSD1306_Gfx_Line(ssd1306_hdl_t const hdl, int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint8_t on)
{
    int16_t dx = (int16_t)(x1 - x0);
    int16_t dy = (int16_t)(y1 - y0);
    int16_t sx = (dx > 0) ? 1 : -1;
    int16_t sy = (dy > 0) ? 1 : -1;
    int16_t err, e2;

    if (dx < 0) dx = (int16_t)-dx;
    if (dy < 0) dy = (int16_t)-dy;
    err = (int16_t)(dx - dy);

    for (;;)
    {
        set_pixel(hdl, x0, y0, on);
        if (x0 == x1 && y0 == y1) break;
        e2 = (int16_t)(err * 2);
        if (e2 > -dy) { err = (int16_t)(err - dy); x0 = (int16_t)(x0 + sx); }
        if (e2 <  dx) { err = (int16_t)(err + dx); y0 = (int16_t)(y0 + sy); }
    }
}

void R_SSD1306_Gfx_Rect(ssd1306_hdl_t const hdl, int16_t x, int16_t y, int16_t w, int16_t h, uint8_t on)
{
    R_SSD1306_Gfx_HLine(hdl, x, y, w, on);
    R_SSD1306_Gfx_HLine(hdl, x, (int16_t)(y + h - 1), w, on);
    R_SSD1306_Gfx_VLine(hdl, x, y, h, on);
    R_SSD1306_Gfx_VLine(hdl, (int16_t)(x + w - 1), y, h, on);
}

void R_SSD1306_Gfx_FillRect(ssd1306_hdl_t const hdl, int16_t x, int16_t y, int16_t w, int16_t h, uint8_t on)
{
    int16_t j;
    for (j = 0; j < h; j++)
    {
        R_SSD1306_Gfx_HLine(hdl, x, (int16_t)(y + j), w, on);
    }
}

void R_SSD1306_Gfx_Circle(ssd1306_hdl_t const hdl, int16_t cx, int16_t cy, int16_t r, uint8_t on)
{
    int16_t x = r;
    int16_t y = 0;
    int16_t d = (int16_t)(1 - r);

    while (x >= y)
    {
        set_pixel(hdl, (int16_t)(cx + x), (int16_t)(cy + y), on);
        set_pixel(hdl, (int16_t)(cx + y), (int16_t)(cy + x), on);
        set_pixel(hdl, (int16_t)(cx - y), (int16_t)(cy + x), on);
        set_pixel(hdl, (int16_t)(cx - x), (int16_t)(cy + y), on);
        set_pixel(hdl, (int16_t)(cx - x), (int16_t)(cy - y), on);
        set_pixel(hdl, (int16_t)(cx - y), (int16_t)(cy - x), on);
        set_pixel(hdl, (int16_t)(cx + y), (int16_t)(cy - x), on);
        set_pixel(hdl, (int16_t)(cx + x), (int16_t)(cy - y), on);
        y++;
        if (d <= 0)
        {
            d = (int16_t)(d + 2 * y + 1);
        }
        else
        {
            x--;
            d = (int16_t)(d + 2 * (y - x) + 1);
        }
    }
}

int16_t R_SSD1306_Gfx_Putc(ssd1306_hdl_t const hdl, int16_t x, int16_t y, char c, uint8_t on)
{
    const uint8_t * glyph;
    int row, col;

    glyph = r_ssd1306_rx_font_glyph(c);
    for (row = 0; row < 8; row++)
    {
        uint8_t bits = glyph[row];
        for (col = 0; col < 8; col++)
        {
            if (bits & (uint8_t)(1u << col))
            {
                set_pixel(hdl, (int16_t)(x + col), (int16_t)(y + row), on);
            }
        }
    }
    return 8;
}

int16_t R_SSD1306_Gfx_Puts(ssd1306_hdl_t const hdl, int16_t x, int16_t y, const char * s, uint8_t on)
{
    while (*s)
    {
        x = (int16_t)(x + R_SSD1306_Gfx_Putc(hdl, x, y, *s++, on));
    }
    return x;
}

#endif /* SSD1306_CFG_ENABLE_GFX */
