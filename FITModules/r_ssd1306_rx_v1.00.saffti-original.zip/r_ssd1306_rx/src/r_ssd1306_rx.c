/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_ssd1306_rx.c
* Description  : SSD1306 128x64 monochrome OLED driver, backend-agnostic main API.
***********************************************************************************************************************/
#include <string.h>
#include "r_ssd1306_rx_private.h"

/* Statically allocated single-instance control block. SSD1306 over I2C is a
 * singleton use case in typical FIT deployments; if multiple displays are
 * ever needed the control block can be moved to a pool without affecting the
 * public API. */
static ssd1306_ctrl_t s_ctrl;

static const uint8_t s_init_cmds[] = {
    0xAE,       /* Display OFF */
    0xD5, 0x80, /* Osc freq / clk div */
    0xA8, 0x3F, /* MUX ratio 64 */
    0xD3, 0x00, /* Display offset 0 */
    0x40,       /* Start line 0 */
    0x8D, 0x14, /* Charge pump ON */
    0x20, 0x00, /* Horizontal addressing */
#if (SSD1306_CFG_ROTATE_180 == 1)
    0xA1,       /* Segment remap (180-deg rotation) */
    0xC8,       /* COM scan remapped */
#else
    0xA0,
    0xC0,
#endif
    0xDA, 0x12, /* COM pins: alternative, no remap */
    0x81, 0xCF, /* Contrast */
    0xD9, 0xF1, /* Pre-charge */
    0xDB, 0x40, /* VCOMH deselect */
    0xA4,       /* Display follows RAM */
    0xA6,       /* Normal (non-inverted) */
    0xAF        /* Display ON */
};

static ssd1306_err_t send_cmd_buf(const uint8_t * cmds, uint32_t len)
{
    return r_ssd1306_rx_i2c_send(SSD1306_CTRL_CMD, cmds, len);
}

static ssd1306_err_t flush_pages_internal(ssd1306_hdl_t const hdl, int8_t page_start, int8_t page_end)
{
    uint8_t col_cmd[3]  = { 0x21, 0x00, (uint8_t)(SSD1306_WIDTH - 1) };
    uint8_t page_cmd[3] = { 0x22, 0, 0 };
    uint32_t bytes;
    ssd1306_err_t err;

    if (page_start < 0) page_start = 0;
    if (page_end   >= SSD1306_PAGES) page_end = (int8_t)(SSD1306_PAGES - 1);
    if (page_start > page_end) return SSD1306_ERR_INVALID_ARG;

    page_cmd[1] = (uint8_t)page_start;
    page_cmd[2] = (uint8_t)page_end;

    err = send_cmd_buf(col_cmd, 3);
    if (err != SSD1306_SUCCESS) return err;
    err = send_cmd_buf(page_cmd, 3);
    if (err != SSD1306_SUCCESS) return err;

    bytes = (uint32_t)(page_end - page_start + 1) * SSD1306_WIDTH;
    return r_ssd1306_rx_i2c_send(SSD1306_CTRL_DATA, &hdl->fb[page_start * SSD1306_WIDTH], bytes);
}

ssd1306_err_t R_SSD1306_Open(ssd1306_hdl_t * const p_hdl)
{
#if (SSD1306_CFG_PARAM_CHECKING_ENABLE == 1)
    if (p_hdl == NULL) return SSD1306_ERR_NULL_PTR;
#endif

    if (s_ctrl.opened) return SSD1306_ERR_INVALID_ARG;

    memset(&s_ctrl, 0, sizeof(s_ctrl));
    s_ctrl.slv_addr = (uint8_t)SSD1306_CFG_SLAVE_ADDR;

    if (r_ssd1306_rx_i2c_open(s_ctrl.slv_addr) != SSD1306_SUCCESS)
    {
        return SSD1306_ERR_BUS;
    }

    if (send_cmd_buf(s_init_cmds, sizeof(s_init_cmds)) != SSD1306_SUCCESS)
    {
        (void)r_ssd1306_rx_i2c_close();
        return SSD1306_ERR_BUS;
    }

    s_ctrl.opened = 1;
    *p_hdl = &s_ctrl;

    /* Push a cleared framebuffer so the panel starts in a well-defined state.
     * If this fails the panel may still show init garbage but the handle is
     * usable. */
    (void)R_SSD1306_Write(&s_ctrl);
    return SSD1306_SUCCESS;
}

ssd1306_err_t R_SSD1306_Close(ssd1306_hdl_t const hdl)
{
#if (SSD1306_CFG_PARAM_CHECKING_ENABLE == 1)
    if (hdl == NULL) return SSD1306_ERR_NULL_PTR;
#endif
    if (!hdl->opened) return SSD1306_ERR_NOT_OPEN;

    {
        uint8_t off = 0xAE;
        (void)send_cmd_buf(&off, 1);
    }
    (void)r_ssd1306_rx_i2c_close();
    hdl->opened = 0;
    return SSD1306_SUCCESS;
}

ssd1306_err_t R_SSD1306_Write(ssd1306_hdl_t const hdl)
{
    ssd1306_err_t err;
#if (SSD1306_CFG_PARAM_CHECKING_ENABLE == 1)
    if (hdl == NULL) return SSD1306_ERR_NULL_PTR;
#endif
    if (!hdl->opened) return SSD1306_ERR_NOT_OPEN;

    err = flush_pages_internal(hdl, 0, (int8_t)(SSD1306_PAGES - 1));
    if (err == SSD1306_SUCCESS)
    {
        /* Keep prev_fb in sync so CMD_FLUSH_DIRTY deltas remain consistent. */
        memcpy(hdl->prev_fb, hdl->fb, SSD1306_BUF_SIZE);
    }
    return err;
}

static int flush_dirty_internal(ssd1306_hdl_t const hdl)
{
    uint8_t dirty[SSD1306_PAGES];
    int p, pages_sent = 0;
    int range_start = -1;

    for (p = 0; p < SSD1306_PAGES; p++)
    {
        int base = p * SSD1306_WIDTH;
        dirty[p] = (memcmp(&hdl->fb[base], &hdl->prev_fb[base], SSD1306_WIDTH) != 0) ? 1 : 0;
    }

    for (p = 0; p < SSD1306_PAGES; p++)
    {
        if (dirty[p])
        {
            if (range_start < 0) range_start = p;
        }
        else if (range_start >= 0)
        {
            (void)flush_pages_internal(hdl, (int8_t)range_start, (int8_t)(p - 1));
            pages_sent += (p - range_start);
            range_start = -1;
        }
    }
    if (range_start >= 0)
    {
        (void)flush_pages_internal(hdl, (int8_t)range_start, (int8_t)(SSD1306_PAGES - 1));
        pages_sent += (SSD1306_PAGES - range_start);
    }

    memcpy(hdl->prev_fb, hdl->fb, SSD1306_BUF_SIZE);
    return pages_sent;
}

ssd1306_err_t R_SSD1306_Control(ssd1306_hdl_t const hdl, ssd1306_cmd_t cmd, void * p_args)
{
#if (SSD1306_CFG_PARAM_CHECKING_ENABLE == 1)
    if (hdl == NULL) return SSD1306_ERR_NULL_PTR;
#endif
    if (!hdl->opened) return SSD1306_ERR_NOT_OPEN;

    switch (cmd)
    {
        case SSD1306_CMD_CLEAR:
            memset(hdl->fb, 0x00, SSD1306_BUF_SIZE);
            return SSD1306_SUCCESS;

        case SSD1306_CMD_SET_PIXEL:
        {
            ssd1306_pixel_arg_t * a = (ssd1306_pixel_arg_t *)p_args;
#if (SSD1306_CFG_PARAM_CHECKING_ENABLE == 1)
            if (a == NULL) return SSD1306_ERR_NULL_PTR;
#endif
            if ((unsigned)a->x >= SSD1306_WIDTH || (unsigned)a->y >= SSD1306_HEIGHT)
            {
                return SSD1306_SUCCESS;  /* off-screen pixels silently clipped */
            }
            {
                uint32_t idx = (uint32_t)a->x + ((uint32_t)a->y / 8u) * SSD1306_WIDTH;
                uint8_t  bit = (uint8_t)(1u << ((uint32_t)a->y & 7u));
                if (a->on) hdl->fb[idx] |=  bit;
                else       hdl->fb[idx] &= (uint8_t)~bit;
            }
            return SSD1306_SUCCESS;
        }

        case SSD1306_CMD_FLUSH:
            return R_SSD1306_Write(hdl);

        case SSD1306_CMD_FLUSH_DIRTY:
        {
            int sent = flush_dirty_internal(hdl);
            if (p_args != NULL) *(int *)p_args = sent;
            return SSD1306_SUCCESS;
        }

        case SSD1306_CMD_FLUSH_PAGES:
        {
            ssd1306_page_range_t * r = (ssd1306_page_range_t *)p_args;
#if (SSD1306_CFG_PARAM_CHECKING_ENABLE == 1)
            if (r == NULL) return SSD1306_ERR_NULL_PTR;
#endif
            return flush_pages_internal(hdl, r->page_start, r->page_end);
        }

        case SSD1306_CMD_SEND_RAW_CMD:
        {
            uint8_t * b = (uint8_t *)p_args;
#if (SSD1306_CFG_PARAM_CHECKING_ENABLE == 1)
            if (b == NULL) return SSD1306_ERR_NULL_PTR;
#endif
            return send_cmd_buf(b, 1);
        }

        case SSD1306_CMD_GET_BUFFER:
        {
            uint8_t ** pp = (uint8_t **)p_args;
#if (SSD1306_CFG_PARAM_CHECKING_ENABLE == 1)
            if (pp == NULL) return SSD1306_ERR_NULL_PTR;
#endif
            *pp = hdl->fb;
            return SSD1306_SUCCESS;
        }

        case SSD1306_CMD_SET_INVERT:
        {
            uint8_t * v = (uint8_t *)p_args;
            uint8_t   op;
#if (SSD1306_CFG_PARAM_CHECKING_ENABLE == 1)
            if (v == NULL) return SSD1306_ERR_NULL_PTR;
#endif
            op = (*v) ? 0xA7u : 0xA6u;
            return send_cmd_buf(&op, 1);
        }

        case SSD1306_CMD_SET_DISPLAY_ON:
        {
            uint8_t * v = (uint8_t *)p_args;
            uint8_t   op;
#if (SSD1306_CFG_PARAM_CHECKING_ENABLE == 1)
            if (v == NULL) return SSD1306_ERR_NULL_PTR;
#endif
            op = (*v) ? 0xAFu : 0xAEu;
            return send_cmd_buf(&op, 1);
        }

        default:
            return SSD1306_ERR_UNSUPPORTED;
    }
}

uint32_t R_SSD1306_GetVersion(void)
{
    return ((uint32_t)SSD1306_VERSION_MAJOR << 16) | (uint32_t)SSD1306_VERSION_MINOR;
}
