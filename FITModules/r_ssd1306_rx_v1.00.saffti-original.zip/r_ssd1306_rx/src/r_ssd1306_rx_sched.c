/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_ssd1306_rx_sched.c
* Description  : Optional fixed-rate frame scheduler backed by r_cmt_rx.
***********************************************************************************************************************/
#include "r_ssd1306_rx_private.h"

#if (SSD1306_CFG_ENABLE_FRAME_SCHED == 1)

#include "r_cmt_rx_if.h"

static volatile uint32_t s_frames;
static uint32_t          s_fps;
static uint32_t          s_cmt_channel;

static void on_tick(void * pdata)
{
    (void)pdata;
    s_frames++;
}

ssd1306_err_t R_SSD1306_FrameSched_Init(uint32_t fps)
{
    bool ok;
    if (fps == 0) return SSD1306_ERR_INVALID_ARG;
    s_frames = 0;
    s_fps = fps;
    ok = R_CMT_CreatePeriodic(fps, on_tick, &s_cmt_channel);
    return ok ? SSD1306_SUCCESS : SSD1306_ERR_BUS;
}

void R_SSD1306_FrameSched_Wait(void)
{
    uint32_t start = s_frames;
    while (s_frames == start) { /* spin */ }
}

uint32_t R_SSD1306_FrameSched_Frames(void) { return s_frames; }
uint32_t R_SSD1306_FrameSched_Fps(void)    { return s_fps; }

#endif /* SSD1306_CFG_ENABLE_FRAME_SCHED */
