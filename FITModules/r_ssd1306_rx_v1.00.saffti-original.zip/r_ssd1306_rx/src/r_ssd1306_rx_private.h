/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
#ifndef R_SSD1306_RX_PRIVATE_H
#define R_SSD1306_RX_PRIVATE_H

#include "r_ssd1306_rx_if.h"

/* SSD1306 control byte selectors (Co=0, D/C#) */
#define SSD1306_CTRL_CMD            (0x00u)
#define SSD1306_CTRL_DATA           (0x40u)

/* Module internal handle. Marked non-null in open() and cleared on close(). */
struct st_ssd1306_ctrl
{
    uint8_t  opened;
    uint8_t  slv_addr;
    uint8_t  fb[SSD1306_BUF_SIZE];
    uint8_t  prev_fb[SSD1306_BUF_SIZE];
};

/* I2C backend API (static-linkable within the module) */
ssd1306_err_t r_ssd1306_rx_i2c_open (uint8_t slv_addr7);
ssd1306_err_t r_ssd1306_rx_i2c_send (uint8_t ctrl_byte, const uint8_t * data, uint32_t len);
ssd1306_err_t r_ssd1306_rx_i2c_close(void);

#if (SSD1306_CFG_ENABLE_GFX == 1)
/* Font glyph lookup (8x8 basic ASCII, 0x20..0x7E). */
const uint8_t * r_ssd1306_rx_font_glyph(char c);
#endif

#endif /* R_SSD1306_RX_PRIVATE_H */
