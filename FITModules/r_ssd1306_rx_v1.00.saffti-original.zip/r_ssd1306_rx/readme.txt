r_ssd1306_rx
============

Overview
--------------------------------------------------------------------------------
The r_ssd1306_rx module drives SSD1306-based 128x64 (or 128x32) monochrome
OLED panels over I2C. The underlying I2C bus is selected at build time through
SSD1306_CFG_I2C_BACKEND in r_ssd1306_rx_config.h:

    0 = r_riic_rx     (RIIC peripheral, up to Fast Mode Plus 1 MHz)
    1 = r_sci_iic_rx  (SCI simple I2C, up to 384 kHz)

The public API is Renesas FIT style: R_SSD1306_Open/Close/Write/Control/
GetVersion. The module additionally ships optional helpers:

    * R_SSD1306_Gfx_*        - graphics primitives (lines, rects, circle,
                               8x8 ASCII font text)
    * R_SSD1306_FrameSched_* - fixed-rate frame scheduler backed by r_cmt_rx

These helpers can be compiled out via SSD1306_CFG_ENABLE_GFX and
SSD1306_CFG_ENABLE_FRAME_SCHED when the application provides its own
equivalents.


Features
--------
* Framebuffer resident in the control block (1 KB for 128x64).
* Full flush (R_SSD1306_Write) or dirty-page flush with contiguous-range
  coalescing (SSD1306_CMD_FLUSH_DIRTY) for sparse updates.
* Optional 180-degree rotation at init time.
* Raw SSD1306 command pass-through (SSD1306_CMD_SEND_RAW_CMD).
* Invert / display on-off controls.
* Backend-agnostic I2C wrapper - application code does not need to know which
  FIT I2C driver is underneath.


File Structure
--------------
r_ssd1306_rx
|   readme.txt
|   r_ssd1306_rx_if.h
|
+---doc
|    +---en
|    |      readme.md
|    |
|    +---ja
|           readme.md
|
+---src
|       r_ssd1306_rx.c
|       r_ssd1306_rx_private.h
|       r_ssd1306_rx_i2c.c
|       r_ssd1306_rx_gfx.c
|       r_ssd1306_rx_sched.c
|       r_ssd1306_rx_font.c

r_config
    r_ssd1306_rx_config.h


Dependencies
------------
Hard:
* r_bsp

Optional (add via Smart Configurator only when the matching feature is enabled,
otherwise unused backend code raises compile errors such as
"SCI_IIC_CFG_CHx_INCLUDED is all 0"):
* r_riic_rx    (when SSD1306_CFG_I2C_BACKEND == 0)
* r_sci_iic_rx (when SSD1306_CFG_I2C_BACKEND == 1)
* r_cmt_rx     (when SSD1306_CFG_ENABLE_FRAME_SCHED == 1)


License
-------
BSD-3-Clause (see license.md at the package root).
