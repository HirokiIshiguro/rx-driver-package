# r_ssd1306_rx — SSD1306 128x64 OLED FIT module for RX

SSD1306 monochrome OLED driver for Renesas RX family MCUs, packaged as a FIT module.
I2C backend is selected between [`r_riic_rx`](https://github.com/renesas/rx-driver-package) and
[`r_sci_iic_rx`](https://github.com/renesas/rx-driver-package) via a configuration macro.

See [readme.txt](../../readme.txt) for the canonical package overview and file structure.

## Minimum example

```c
#include "r_ssd1306_rx_if.h"

void demo(void)
{
    ssd1306_hdl_t hdl;

    if (R_SSD1306_Open(&hdl) != SSD1306_SUCCESS) return;

    R_SSD1306_Gfx_Puts(hdl, 0, 0, "Hello SSD1306", 1);
    R_SSD1306_Gfx_Rect(hdl, 0, 10, 128, 20, 1);

    (void)R_SSD1306_Write(hdl);
}
```

## Reference application

A full-featured reference application using this module is
[128_64_display_badapple](https://gitlab.saffti.jp/oss/experiment/embedded/mcu/renesas/rx/example/tb-rx671/128_64_display_badapple)
on TB-RX671.
