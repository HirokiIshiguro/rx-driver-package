# r_ssd1306_rx — RX 用 SSD1306 128x64 OLED FIT モジュール

Renesas RX ファミリ用の SSD1306 モノクロ OLED ドライバを FIT モジュール形式で提供します。
I2C バックエンドは設定マクロで [`r_riic_rx`](https://github.com/renesas/rx-driver-package) と
[`r_sci_iic_rx`](https://github.com/renesas/rx-driver-package) のいずれかを選択できます。

パッケージ概要・ファイル構成は [readme.txt](../../readme.txt) を参照してください。

## 最小サンプル

```c
#include "r_ssd1306_rx_if.h"

void demo(void)
{
    ssd1306_hdl_t hdl;

    if (R_SSD1306_Open(&hdl) != SSD1306_SUCCESS) return;

    R_SSD1306_Gfx_Puts(hdl, 0, 0, "Hello SSD1306", 1);
    R_SSD1306_Gfx_Rect(hdl, 0, 10, 128, 20, 1);

    (void)R_SSD1306_Write(hdl);
}
```

## リファレンスアプリ

TB-RX671 上で本モジュールを利用したフル機能リファレンスとして
[128_64_display_badapple](https://gitlab.saffti.jp/oss/experiment/embedded/mcu/renesas/rx/example/tb-rx671/128_64_display_badapple)
があります。
