/*
* Copyright (c) 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/**********************************************************************************************************************
 * File Name    : r_wifi_da16xxx_config.h
 * Description  : DA16XXX WiFi driver Configuration.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#ifndef R_WIFI_DA16XXX_CONFIG_H
#define R_WIFI_DA16XXX_CONFIG_H

/* Enable DA16600 support
   0 = Disable
   1 = Enable
 */
#define WIFI_CFG_DA16600_SUPPORT              (0)

/* SCI Channel for AT command communication
   Set this option to match the SCI port to be controlled.
 */
#define WIFI_CFG_SCI_CHANNEL                  (6)

/* Interrupt priority of the serial module used for communication with the Wi-Fi module.
   Set this option to a value of 1 to 15 to match the system priority
 */
#define WIFI_CFG_SCI_INTERRUPT_LEVEL          (4)

/* Peripheral clock speed for WIFI_CFG_SCI_CHANNEL
 */
#define WIFI_CFG_SCI_PCLK_HZ                  (60000000)

/* Communication baud rate for WIFI_CFG_SCI_CHANNEL
   Value must be 115200/230400/460800/921600
 */
#define WIFI_CFG_SCI_BAUDRATE                 (115200)

/* UART hardware flow control
   0 = CTS(Hardware), RTS(Software)
   1 = RTS(Hardware), CTS(Software)
 */
#define WIFI_CFG_CTS_SW_CTRL                  (1)

/* Configure CTS pin
 */
#define WIFI_CFG_CTS_PORT                     J
#define WIFI_CFG_CTS_PIN                      3

/* Configure RTS pin
 */
#define WIFI_CFG_RTS_PORT                     J
#define WIFI_CFG_RTS_PIN                      3

/* RTS pin function set value
 */
#define WIFI_CFG_PFS_SET_VALUE                0x0AU

/* Configure RESET pin
 */
#define WIFI_CFG_RESET_PORT                   5
#define WIFI_CFG_RESET_PIN                    5

/* Board dependent settings; please use the value for each setting listed below depending on the board you use.

Preprocessors that define board dependent settings and the corresponding values to be set are as follows:
Confirmed board number          1       2      3      4      5      6      7      8      9      10     11     12     13     14     15     16
WIFI_CFG_SCI_CHANNEL            0       2      6      1      6      0      6      2      5      5      5      5      10     11     5      1
WIFI_CFG_SCI_PCLK_HZ (*Note1)
WIFI_CFG_CTS_PORT               2       J      J      3      J      2      J      J      C      C      C      C      8      7      A      1
WIFI_CFG_CTS_PIN                3       5      3      1      3      3      3      5      0      0      0      0      3      4      6      4
WIFI_CFG_RTS_PORT               2       J      J      3      J      2      J      J      C      C      C      C      8      7      A      3
WIFI_CFG_RTS_PIN                3       5      3      1      3      3      3      5      0      0      0      0      0      5      1      1
WIFI_CFG_PFS_SET_VALUE (*Note2) 0x0BU   0x0BU  0x0AU  0x0BU  0x0AU  0x0BU  0x0AU  0x0BU  0x0BU  0x0BU  0x0BU  0x0BU  0X2DU  0X2DU  0x0BU  0x0BU
WIFI_CFG_RESET_PORT             D       5      F      2      5      A      5      A      B      B      D      D      4      C      B      B
WIFI_CFG_RESET_PIN              0       5      5      0      5      1      5      1      1      1      7      7      7      0      3      2

where the confirmed board numbers listed in the first row above are as follows (*Note3):
1: RX65N Cloud Kit (PMOD),
2: RX65N Envision Kit (PMOD),
3: RX65N RSK (2MB) (PMOD1),
4: RX65N RSK (2MB) (PMOD2),
5: Cloud Kit for RX65N v1, CK-RX65N v1 (PMOD1),
6: Cloud Kit for RX65N v1, CK-RX65N v1 (PMOD2),
7: Cloud Kit for RX65N v2, CK-RX65N v2 (PMOD1),
8: Cloud Kit for RX65N v2, CK-RX65N v2 (PMOD2),
9: RX671 Target Board (PMOD),         (*Note4)
10: RX66N Target Board (PMOD),        (*Note5)
11: FPB-RX261 (PMOD1),                (*Note6)
12: EK-RX261  (PMOD1),
13: EK-RX671  (PMOD1),
14: EK-RX671  (PMOD2),
15: FPB-RX140 (PMOD1),
16: FPB-RX140 (PMOD2),
In the above preprocessor list, please use one of the values listed on the right side.
On the right side, each column corresponds to each confirmed board number.

Note1: Check Peripheral clock speed in Clocks tab on Smart Configuration.
    For Peripheral module clock, check board group hardware manual, Serial Communications Interface section in Note2.
    e.g. if PCLKB speed is 60MHz then WIFI_CFG_SCI_PCLK_HZ is 60000000).

Note2: Check Pin Function Select (PSEL) of Pin Function Control Register (PxyPFS)
    In Multi-Function Pin Controller (MPC) section of board group hardware manual.
    Below is list of board group hardware manual:
    1: RX65N group: https://www.renesas.com/us/en/document/mah/rx65n-group-rx651-group-users-manualhardware-rev230
    2: RX671 group: https://www.renesas.com/tw/en/document/mah/rx671-group-users-manual-hardware-rev100
    3: RX66N group: https://www.renesas.com/us/en/document/mah/rx66n-group-users-manual-hardware-rev111
    4: RX261 group: https://www.renesas.com/en/document/mah/rx260-group-rx261-group-users-manual-hardware?r=25565706
    5: RX140 group: https://www.renesas.com/en/document/mah/rx140-group-users-manual-hardware-rev120?r=1531576

Note3: List of board user's manual:
    1: RX65N Cloud Kit:    https://www.renesas.com/us/en/document/mat/uses-manual-cloud-option-board
    2: RX65N Envision Kit: https://www.renesas.com/us/en/document/mat/rx65n-envision-kit-users-manual-rev100
    3: RX65N RSK (2MB):    https://www.renesas.com/us/en/document/mat/renesas-starter-kit-rx65n-2mb-users-manual
    4: CK-RX65N v1:        https://www.renesas.com/kr/en/document/mat/ck-rx65n-v1-users-manual
    5: CK-RX65N v2:        https://www.renesas.com/kr/en/document/mat/ck-rx65n-v2-users-manual
    6: RX671 Target Board: https://www.renesas.com/br/en/document/mat/target-board-rx671-users-manual-rev100
    7: RX66N Target Board: https://www.renesas.com/us/en/document/mah/target-board-rx66n-users-manual-rev100
    8: FPB-RX261          https://www.renesas.com/en/document/mat/fpb-rx261-v1-users-manual
    9: EK-RX261:           https://www.renesas.com/en/document/mat/ek-rx261-v1-users-manual
    10: EK-RX671 v1:        https://www.renesas.com/en/document/mat/ek-rx671-v1-users-manual
    11: FPB-RX140:          https://www.renesas.com/en/document/mat/fpb-rx140-v1-users-manual

Note4:
- When you use RX671 Target Board, you need pattern cut and so on to use SCI channel 5(TXD5/RXD5/CTS5) and GPIO(PC1).
Please refer to User's Manual: https://www.renesas.com/products/microcontrollers-microprocessors/rx-32-bit-performance-efficiency-mcus/rtk5rx6710c00000bj-target-board-rx671

Note5:
- When you use RX66N Target Board, you need remodeling of the board to use SCI channel 5(TXD5/RXD5/CTS5) and GPIO(PC1).
Please refer to User's Manual: https://www.renesas.com/products/microcontrollers-microprocessors/rx-32-bit-performance-efficiency-mcus/rtk5rx66n0c00000bj-target-board-rx66n
- RX66N Target Board not support AzureRTOS.

Note6:
- Only support Bare metal mode.

*/

/* AT command transfer buffer size
   Value must be in the range 1-8192
 */
#define WIFI_CFG_AT_CMD_TX_BUFFER_SIZE          (512)

/* AT command receive buffer size
   Value must be in the range 1-8192
 */
#define WIFI_CFG_AT_CMD_RX_BUFFER_SIZE          (3000)

/* Wi-Fi callback function use
   0 = Unused
   1 = Used
 */
#define WIFI_CFG_USE_CALLBACK_FUNCTION          (0)

#if WIFI_CFG_USE_CALLBACK_FUNCTION == 1

/* Wi-Fi callback function name
 */
#define WIFI_CFG_CALLBACK_FUNCTION_NAME         (NULL)

#endif

/* Max AP's SSID length
   Value must be an decimal value
 */
#define WIFI_CFG_MAX_SSID_LEN                   32

/* Max AP's BSSID length
   Value must be an decimal value
 */
#define WIFI_CFG_MAX_BSSID_LEN                  6

/* Max AP's password length
   Value must be an decimal value
 */
#define WIFI_CFG_MAX_PASS_LEN                   32

/* Use SNTP client service
   0 = Disable SNTP client service.
   1 = Enable SNTP client service.
 */
#define WIFI_CFG_SNTP_ENABLE                    0

#if WIFI_CFG_SNTP_ENABLE == 1

/* The SNTP server IP address string
 */
#define WIFI_CFG_SNTP_SERVER_IP                 "0.0.0.0"

/* Timezone offset in hours (-12 ~ 12)
 */
#define WIFI_CFG_SNTP_UTC_OFFSET                7

#endif

/* Country code
   Country code defined in ISO3166-1 alpha-2 standard.
 */
#define WIFI_CFG_COUNTRY_CODE                   ""

/* Logging option to output errors, warnings, status, and other information of Wi-Fi DA16XXX module.
   1 = Using FreeRTOS logging stack for logging output.
   2 = Using serial port for logging output.
   3 = Using Renesas Debug Virtual Console for logging output.
 */
#define WIFI_CFG_LOGGING_OPTION                 0

#if WIFI_CFG_LOGGING_OPTION == 2

/* SCI Channel for logging output if using serial port logging
 */
#define WIFI_CFG_LOG_TERM_CHANNEL               (5)

/* Communication baud rate for serial terminal.
*/
#define WIFI_CFG_SCI_UART_TERMINAL_BAUDRATE      (115200)

/* Interrupt priority for serial terminal.
   0(low) - 15(high)
*/
#define WIFI_CFG_SCI_UART_INTERRUPT_PRIORITY    (1)

#endif

#if WIFI_CFG_LOGGING_OPTION != 0
/* Debug log output level
   0: OFF
   1: ERROR
   2: +WARN
   3: +INFO
   4: +DEBUG(AT command data)
 */
#define WIFI_CFG_DEBUG_LOG                      0

#endif

/* TCP protocol support
   0 = Not use TCP protocol.
   1 = Use TCP protocol.
 */
#define WIFI_CFG_TCP_SUPPORT                    1

/* Creatable TCP Sockets number
   Value must be in the range 1-4
 */
#define WIFI_CFG_TCP_CREATABLE_SOCKETS          (1)

/* Socket Receive buffer size
   Value must be in the range 1-8192
 */
#define WIFI_CFG_TCP_SOCKET_RECEIVE_BUFFER_SIZE (4096)

/* MQTT protocol support
   0 = Not use MQTT protocol
   1 = Use MQTT protocol.
 */
#define WIFI_CFG_MQTT_SUPPORT                   0

/* Use MQTT Certificates
   0 = Not use MQTT Certificates.
   1 = Use MQTT Certificates.
 */
#define WIFI_CFG_MQTT_CERTS                     (0)

#if WIFI_CFG_MQTT_CERTS == 1

/* Certificates|Root CA
   Name of header file that will contain certificates (macros).
   User must create header file.
   Example: "cert_storage.h"
 */
#define WIFI_CFG_MQTT_CERTS_HEADER              /* Header file name */

/* Certificates|Root CA
   Links to user-defined macro of the same name for Root CA
   which user must define in application header.
 */
#define WIFI_CFG_MQTT_ROOT_CA                   /* Root CA */

/* Certificates|Client Certificate
   Links to user-defined macro of the same name for client certificate
   which user must define in application header.
 */
#define WIFI_CFG_MQTT_CLIENT_CERT               /* Client certificate */

/* Certificates|Private Key
   Links to user-defined macro of the same name for private key
   which user must define in application header
 */
#define WIFI_CFG_MQTT_PRIVATE_KEY               /* Client private key */

#endif

/* Size in bytes of the MQTT buffer used for sending commands and publishing data
   Value must be in the range 200~2064 and must be less than or equal to Wi-Fi TX buffer
 */
#define WIFI_CFG_MQTT_CMD_TX_BUF_SIZE           (512)

/* Size in bytes of the MQTT buffer used for receiving subscribed data
   Value must be in the range 1-3000 and must be less than or equal to Wi-Fi RX buffer
 */
#define WIFI_CFG_MQTT_CMD_RX_BUF_SIZE           (512)

/* Use MQTT protocol v3.1.1
   0 = Disable MQTT protocol v3.1.1.
   1 = Enable MQTT protocol v3.1.1.
 */
#define WIFI_CFG_MQTT_USE_MQTT_V311             (1)

/* MQTT Receive Maximum Timeout (ms)
   Timeout for the MQTT Receive function to check the buffer
   for incoming MQTT messages in milliseconds.
   Set between 0~65535
 */
#define WIFI_CFG_MQTT_RX_TIMEOUT                (1000)

/* MQTT Transit Maximum Timeout (ms)
   Timeout for publishing MQTT messages in milliseconds.
   Set between 0~65535
 */
#define WIFI_CFG_MQTT_TX_TIMEOUT                (1000)

/* Use Clean Session
   0 = Disable Clean Session.
   1 = Enable Clean Session.
 */
#define WIFI_CFG_MQTT_CLEAN_SESSION             (1)

/* ALPN1
   Select 1st Application Layer Protocol Negotiations (ALPNs).
 */
#define WIFI_CFG_MQTT_ALPN1                     /* Select ALPN1 */

/* ALPN2
   Select 2nd Application Layer Protocol Negotiations (ALPNs).
 */
#define WIFI_CFG_MQTT_ALPN2                     /* Select ALPN2 */

/* ALPN3
   Select 3rd Application Layer Protocol Negotiations (ALPNs).
 */
#define WIFI_CFG_MQTT_ALPN3                     /* Select ALPN3 */

/* UseKeep Alive (s)
   MQTT ping period to check if connection is still active.
 */
#define WIFI_CFG_MQTT_KEEP_ALIVE                (60)

/* Client Identifier
 */
#define WIFI_CFG_MQTT_CLIENT_IDENTIFIER         /* MQTT Client identifier */

/* Host Name (or IP address)
 */
#define WIFI_CFG_MQTT_HOST_NAME                 /* MQTT broker name */

/* MQTT Port
 */
#define WIFI_CFG_MQTT_PORT                      (1883)

/* MQTT User Name
 */
#define WIFI_CFG_MQTT_USER_NAME                 /* Client user name */

/* MQTT Password
 */
#define WIFI_CFG_MQTT_PASSWORD                  /* Client pass word */

/* Last Will Topic
 */
#define WIFI_CFG_MQTT_WILL_TOPIC                /* Will topic */

/* Last Will Message
 */
#define WIFI_CFG_MQTT_WILL_MESSAGE              /* Will message */

/* Server Name Indication (SNI)
 */
#define WIFI_CFG_MQTT_SNI_NAME                  /* SNI name */

/* Quality-of-Service for MQTT Last Will message
   0: At most once (QoS 0).
   1: At least once (QoS 1).
   2: Exactly once (QoS 2).
 */
#define WIFI_CFG_MQTT_WILL_QOS                  (0)

/* Flag to use TLS Cipher Suites.
   0 = Unused.
   1 = Used.
 */
#define WIFI_CFG_MQTT_TLS_CIPHER_SUITES         (0)

#if WIFI_CFG_MQTT_TLS_CIPHER_SUITES == 1

/* Select TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA Cipher.
    Unused: 0.
    Used: WIFI_TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA
 */
#define WIFI_CFG_MQTT_TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA        (0)

/* Select TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA Cipher.
   Unused: 0.
   Used: WIFI_TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA
 */
#define WIFI_CFG_MQTT_TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA        (0)

/* Select TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 Cipher.
    Unused: 0.
    Used: WIFI_TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256
 */
#define WIFI_CFG_MQTT_TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256     (0)

/* Select TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384 Cipher.
    Unused: 0.
    Used: WIFI_TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384
 */
#define WIFI_CFG_MQTT_TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384     (0)

/* Select TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 Cipher.
    Unused: 0.
    Used: WIFI_TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256
 */
#define WIFI_CFG_MQTT_TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256     (0)

/* Select TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 Cipher.
    Unused: 0.
    Used: WIFI_TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384
 */
#define WIFI_CFG_MQTT_TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384     (0)

/* Select TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA Cipher.
    Unused: 0.
    Used: WIFI_TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA
 */
#define WIFI_CFG_MQTT_TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA      (0)

/* Select TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA Cipher.
    Unused: 0.
    Used: WIFI_TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA
 */
#define WIFI_CFG_MQTT_TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA      (0)

/* Select TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256 Cipher.
    Unused: 0.
    Used: WIFI_TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256
 */
#define WIFI_CFG_MQTT_TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256   (0)

/* Select TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384 Cipher.
    Unused: 0.
    Used: WIFI_TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384
 */
#define WIFI_CFG_MQTT_TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384   (0)

/* Select TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 Cipher.
    Unused: 0.
    Used: WIFI_TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256
 */
#define WIFI_CFG_MQTT_TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256   (0)

/* Select TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 Cipher.
    Unused: 0.
    Used: WIFI_TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384
 */
#define WIFI_CFG_MQTT_TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384   (0)

#endif

/* Enables or disables the user MQTT callback function.
    0 = Unused.
    1 = Used.
 */
#define WIFI_CFG_MQTT_P_CALLBACK                1

#if WIFI_CFG_MQTT_P_CALLBACK == 1

/* Specifies function name of the MQTT callback function called when receive data subscribed.
 */
#define WIFI_CFG_MQTT_P_CALLBACK_FUNCTION_NAME  mqtt_userCallback

#endif

/* Enables or disables TLS on-chip protocol.
    0 = disabled.
    1 = enabled.
 */
#define WIFI_CFG_TLS_SUPPORT                    0

/* Configures the number of TLS client socket.
    Set this value in range from 1 to 2.
 */
#define WIFI_CFG_TLS_CREATABLE_SOCKETS          (1)

/* Configures the receive buffer size for the socket.
    Set this value in range from 1 to 8192.
 */
#define WIFI_CFG_TLS_SOCKET_RECEIVE_BUFFER_SIZE (4096)

/* Flag to use CA certificates.
    0 = Unused.
    1 = Used.
 */
#define WIFI_CFG_TLS_USE_CA_CERT                1

/* Configures length for certificate's name.
 */
#define WIFI_CFG_TLS_CERT_MAX_NAME              32

/* Configures CA certificate name.
 */
#define WIFI_CFG_TLS_CERT_CA_NAME               ""

/* Configures Client certificate name.
 */
#define WIFI_CFG_TLS_CERT_CLIENT_NAME           ""

/* Configures Private certificate name.
 */
#define WIFI_CFG_TLS_CERT_PRIVATE_NAME           ""

/* Enables or disables HTTP on-chip protocol.
    0 = disabled
    1 = enabled
 */
#define WIFI_CFG_HTTP_SUPPORT                    0

/* Configures Server Name Indication (SNI).
 */
#define WIFI_CFG_HTTP_SNI_NAME                  /* SNI name */

/* Select 1st Application Layer Protocol Negotiation (ALPN).
 */
#define WIFI_CFG_HTTP_ALPN1                     /* Select ALPN1 */

/* Select 2nd ALPN.
 */
#define WIFI_CFG_HTTP_ALPN2                     /* Select ALPN2 */

/* Select 3rd ALPN.
 */
#define WIFI_CFG_HTTP_ALPN3                     /* Select ALPN3 */

/* Configures HTTP TLS Authentication levels.
    0: None - No authentication required; accept connections without any form of authentication.
    1: Optional - Allow both authenticated and unauthenticated connections.
    2: Require - Demand authentication for connections.
 */
#define WIFI_CFG_HTTP_TLS_AUTH                  (0)

#if WIFI_CFG_HTTP_TLS_AUTH != 0

/* Name of header file that will contain certificates (macros).
    User must create header file.
    Example: "cert_storage.h"
 */
#define WIFI_CFG_HTTP_CERTS_HEADER              /* Header file name */

/* Root CA
    Links to user-defined macro of the same name for Root CA
    which user must define in application header.
 */
#define WIFI_CFG_HTTP_ROOT_CA                   /* Root CA */

/* Client certificate
    Links to user-defined macro of the same name for client certificate
    which user must define in application header.
 */
#define WIFI_CFG_HTTP_CLIENT_CERT               /* Client certificate */

/* Client private key
    Links to user-defined macro of the same name for private key
    which user must define in application header.
 */
#define WIFI_CFG_HTTP_PRIVATE_KEY               /* Client private key */

#endif

/* End HTTP macro definitions */

/* Start OTA macro definitions */

#define WIFI_CFG_OTA_SUPPORT                   (0)

#if WIFI_CFG_OTA_SUPPORT == 1
/*
 * @brief Block size for OTA data write.
 *
 * Defines the size (in bytes) of each data block written to flash memory
 * during the OTA (Over-the-Air) update process. This value determines how
 * much data is written per write operation.
 */
#define WIFI_CFG_OTA_BLK_SIZE                  (128)

/* Configures the certificate verification mode.
    0: None - No authentication required; accept connections without any form of authentication.
    1: Optional - Allow both authenticated and unauthenticated connections.
    2: Require - Demand authentication for connections.
 */
#define WIFI_CFG_OTA_TLS_AUTH                  (0)

#if WIFI_CFG_OTA_TLS_AUTH != 0

/* Name of header file that will contain certificates (macros).
    User must create header file.
    Example: "cert_storage.h"
 */
#define WIFI_CFG_OTA_CERTS_HEADER              ""

/* Root CA
    Links to user-defined macro of the same name for Root CA
    which user must define in application header.
 */
#define WIFI_CFG_OTA_ROOT_CA                   /* Root CA */

#endif /* End WIFI_CFG_OTA_TLS_AUTH != 0 */

#endif /* End WIFI_CFG_OTA_SUPPORT == 1 */

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/

#endif /* R_WIFI_DA16XXX_CONFIG_H */
