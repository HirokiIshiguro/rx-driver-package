/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
#ifndef RM_LITTLEFS_RX_CONFIG_H
#define RM_LITTLEFS_RX_CONFIG_H

#define RM_LITTLEFS_CFG_READ_SIZE               (4u)
#define RM_LITTLEFS_CFG_PROG_SIZE               (4u)
#define RM_LITTLEFS_CFG_BLOCK_SIZE              (128u)
#define RM_LITTLEFS_CFG_CACHE_SIZE              (64u)
#define RM_LITTLEFS_CFG_LOOKAHEAD_SIZE          (16u)
#define RM_LITTLEFS_CFG_BLOCK_CYCLES            (500)
#define RM_LITTLEFS_CFG_FORMAT_IF_MOUNT_FAILED  (0u)
#define RM_LITTLEFS_CFG_PARAM_CHECKING_ENABLE   (1u)
#define RM_LITTLEFS_CFG_PROVIDE_ABORT           (1u)

#endif /* RM_LITTLEFS_RX_CONFIG_H */
