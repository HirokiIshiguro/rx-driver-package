# rm_littlefs_rx

Renesas RX のデータフラッシュ領域を littlefs v2 として mount する FIT ミドルウェアです。

