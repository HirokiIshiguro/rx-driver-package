/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
#include <stdint.h>
#include <stddef.h>
#include <string.h>

#include "platform.h"
#include "r_flash_rx_if.h"
#include "rm_sfd_rx_if.h"

#define RM_SFD_SLOT_COUNT             (2u)
#define RM_SFD_DATA_STATUS_EMPTY      (0u)
#define RM_SFD_DATA_STATUS_REGISTERED (1u)

typedef struct st_rm_sfd_descriptor
{
    uint8_t label[RM_SFD_CFG_LABEL_MAX_BYTES];
    uint32_t label_length;
    uint32_t storage_offset;
    uint32_t data_length;
    uint32_t status;
    rm_sfd_handle_t handle;
} rm_sfd_descriptor_t;

typedef struct st_rm_sfd_slot_header
{
    uint32_t magic;
    uint32_t version;
    uint32_t generation;
    uint32_t slot_size;
    uint32_t object_count_max;
    uint32_t storage_size;
    uint32_t crc32;
    uint32_t reserved;
} rm_sfd_slot_header_t;

enum
{
    RM_SFD_STORAGE_SIZE = (int) (RM_SFD_CFG_SLOT_SIZE_BYTES - sizeof(rm_sfd_slot_header_t) -
                          (sizeof(rm_sfd_descriptor_t) * RM_SFD_CFG_MAX_OBJECTS))
};

typedef struct st_rm_sfd_slot_image
{
    rm_sfd_slot_header_t header;
    rm_sfd_descriptor_t descriptors[RM_SFD_CFG_MAX_OBJECTS];
    uint8_t storage[RM_SFD_STORAGE_SIZE];
} rm_sfd_slot_image_t;

typedef struct st_rm_sfd_ctrl
{
    uint32_t opened;
    uint32_t base_address;
    uint32_t region_size;
    uint32_t slot_size;
    uint32_t active_slot;
    rm_sfd_slot_image_t image;
} rm_sfd_ctrl_t;

static rm_sfd_ctrl_t g_rm_sfd_ctrl;
static rm_sfd_slot_image_t g_rm_sfd_probe_slot;
static rm_sfd_slot_image_t g_rm_sfd_next_slot;

static uint32_t rm_sfd_crc32_update(uint32_t crc, uint8_t const * p_data, uint32_t length);
static uint32_t rm_sfd_crc32_finish(uint32_t crc);
static uint32_t rm_sfd_image_crc(rm_sfd_slot_image_t const * p_image);
static uint32_t rm_sfd_image_is_valid(rm_sfd_slot_image_t const * p_image, uint32_t slot_size);
static void rm_sfd_image_init(rm_sfd_slot_image_t * p_image, uint32_t slot_size, uint32_t generation);
static rm_sfd_err_t rm_sfd_read_slot(uint32_t slot, rm_sfd_slot_image_t * p_image);
static rm_sfd_err_t rm_sfd_commit(uint32_t next_slot);
static rm_sfd_err_t rm_sfd_flash_wait_ready(void);
static rm_sfd_err_t rm_sfd_flash_write_slot(uint32_t slot, rm_sfd_slot_image_t const * p_image);
static uint32_t rm_sfd_used_bytes(void);
static uint32_t rm_sfd_object_count(void);
static rm_sfd_handle_t rm_sfd_next_handle(void);
static int32_t rm_sfd_find_label(uint8_t const * p_label, uint32_t label_length);
static int32_t rm_sfd_find_handle(rm_sfd_handle_t handle);
static rm_sfd_err_t rm_sfd_repack_without(int32_t skip_index,
                                          uint8_t const * p_new_label,
                                          uint32_t new_label_length,
                                          uint8_t const * p_new_data,
                                          uint32_t new_data_length,
                                          rm_sfd_handle_t new_handle);
static flash_err_t rm_sfd_flash_open(uint32_t * p_close_on_exit);
static void rm_sfd_flash_close(uint32_t close_on_exit);

rm_sfd_err_t RM_SFD_Open(rm_sfd_cfg_t const * p_cfg)
{
    uint32_t slot0_valid;
    uint32_t slot1_valid;
    uint32_t close_flash_on_exit = 0u;
    rm_sfd_err_t err;

#if (RM_SFD_CFG_PARAM_CHECKING_ENABLE)
    if ((NULL == p_cfg) || (0u == p_cfg->base_address) || (0u == p_cfg->region_size))
    {
        return RM_SFD_ERR_INVALID_ARGUMENT;
    }
#endif

    if ((0u != (p_cfg->region_size % RM_SFD_SLOT_COUNT)) ||
        ((p_cfg->region_size / RM_SFD_SLOT_COUNT) != RM_SFD_CFG_SLOT_SIZE_BYTES) ||
        (0u != (p_cfg->base_address % FLASH_DF_BLOCK_SIZE)) ||
        (0u != ((p_cfg->region_size / RM_SFD_SLOT_COUNT) % FLASH_DF_BLOCK_SIZE)))
    {
        return RM_SFD_ERR_INVALID_ARGUMENT;
    }

    memset(&g_rm_sfd_ctrl, 0, sizeof(g_rm_sfd_ctrl));
    g_rm_sfd_ctrl.base_address = p_cfg->base_address;
    g_rm_sfd_ctrl.region_size = p_cfg->region_size;
    g_rm_sfd_ctrl.slot_size = p_cfg->region_size / RM_SFD_SLOT_COUNT;

    if (FLASH_SUCCESS != rm_sfd_flash_open(&close_flash_on_exit))
    {
        return RM_SFD_ERR_FLASH;
    }

    err = rm_sfd_read_slot(0u, &g_rm_sfd_ctrl.image);
    if (RM_SFD_SUCCESS != err)
    {
        rm_sfd_flash_close(close_flash_on_exit);
        return err;
    }
    err = rm_sfd_read_slot(1u, &g_rm_sfd_probe_slot);
    if (RM_SFD_SUCCESS != err)
    {
        rm_sfd_flash_close(close_flash_on_exit);
        return err;
    }

    slot0_valid = rm_sfd_image_is_valid(&g_rm_sfd_ctrl.image, g_rm_sfd_ctrl.slot_size);
    slot1_valid = rm_sfd_image_is_valid(&g_rm_sfd_probe_slot, g_rm_sfd_ctrl.slot_size);

    if ((0u != slot0_valid) &&
        ((0u == slot1_valid) || (g_rm_sfd_ctrl.image.header.generation >= g_rm_sfd_probe_slot.header.generation)))
    {
        g_rm_sfd_ctrl.active_slot = 0u;
    }
    else if (0u != slot1_valid)
    {
        memcpy(&g_rm_sfd_ctrl.image, &g_rm_sfd_probe_slot, sizeof(g_rm_sfd_ctrl.image));
        g_rm_sfd_ctrl.active_slot = 1u;
    }
    else
    {
        rm_sfd_image_init(&g_rm_sfd_ctrl.image, g_rm_sfd_ctrl.slot_size, 1u);
        g_rm_sfd_ctrl.active_slot = 0u;
        err = rm_sfd_flash_write_slot(g_rm_sfd_ctrl.active_slot, &g_rm_sfd_ctrl.image);
        if (RM_SFD_SUCCESS != err)
        {
            rm_sfd_flash_close(close_flash_on_exit);
            return err;
        }
    }

    g_rm_sfd_ctrl.opened = 1u;
    rm_sfd_flash_close(close_flash_on_exit);
    return RM_SFD_SUCCESS;
}

rm_sfd_err_t RM_SFD_Close(void)
{
    memset(&g_rm_sfd_ctrl, 0, sizeof(g_rm_sfd_ctrl));
    return RM_SFD_SUCCESS;
}

rm_sfd_err_t RM_SFD_Format(void)
{
    rm_sfd_err_t err;
    uint32_t close_flash_on_exit = 0u;

    if (0u == g_rm_sfd_ctrl.opened)
    {
        return RM_SFD_ERR_NOT_OPEN;
    }

    if (FLASH_SUCCESS != rm_sfd_flash_open(&close_flash_on_exit))
    {
        return RM_SFD_ERR_FLASH;
    }

    rm_sfd_image_init(&g_rm_sfd_ctrl.image, g_rm_sfd_ctrl.slot_size, g_rm_sfd_ctrl.image.header.generation + 1u);
    err = rm_sfd_flash_write_slot(0u, &g_rm_sfd_ctrl.image);
    if (RM_SFD_SUCCESS == err)
    {
        g_rm_sfd_ctrl.active_slot = 0u;
        err = rm_sfd_flash_write_slot(1u, &g_rm_sfd_ctrl.image);
    }
    rm_sfd_flash_close(close_flash_on_exit);
    return err;
}

rm_sfd_err_t RM_SFD_SaveObject(uint8_t const * p_label,
                               uint32_t label_length,
                               uint8_t const * p_data,
                               uint32_t data_length,
                               rm_sfd_handle_t * p_handle)
{
    int32_t existing;
    rm_sfd_handle_t handle;
    rm_sfd_err_t err;
    uint32_t close_flash_on_exit = 0u;

    if (0u == g_rm_sfd_ctrl.opened)
    {
        return RM_SFD_ERR_NOT_OPEN;
    }
#if (RM_SFD_CFG_PARAM_CHECKING_ENABLE)
    if ((NULL == p_label) || (0u == label_length) || (label_length > RM_SFD_CFG_LABEL_MAX_BYTES) ||
        ((NULL == p_data) && (0u != data_length)) || (NULL == p_handle))
    {
        return RM_SFD_ERR_INVALID_ARGUMENT;
    }
#endif

    existing = rm_sfd_find_label(p_label, label_length);
    if (existing >= 0)
    {
        handle = g_rm_sfd_ctrl.image.descriptors[existing].handle;
    }
    else
    {
        handle = rm_sfd_next_handle();
        if (RM_SFD_HANDLE_INVALID == handle)
        {
            return RM_SFD_ERR_NO_SPACE;
        }
    }

    err = rm_sfd_repack_without(existing, p_label, label_length, p_data, data_length, handle);
    if (RM_SFD_SUCCESS != err)
    {
        return err;
    }

    if (FLASH_SUCCESS != rm_sfd_flash_open(&close_flash_on_exit))
    {
        return RM_SFD_ERR_FLASH;
    }
    err = rm_sfd_commit(1u - g_rm_sfd_ctrl.active_slot);
    rm_sfd_flash_close(close_flash_on_exit);

    if (RM_SFD_SUCCESS == err)
    {
        *p_handle = handle;
    }
    return err;
}

rm_sfd_err_t RM_SFD_FindObject(uint8_t const * p_label,
                               uint32_t label_length,
                               rm_sfd_handle_t * p_handle)
{
    int32_t index;

    if (0u == g_rm_sfd_ctrl.opened)
    {
        return RM_SFD_ERR_NOT_OPEN;
    }
#if (RM_SFD_CFG_PARAM_CHECKING_ENABLE)
    if ((NULL == p_label) || (0u == label_length) || (label_length > RM_SFD_CFG_LABEL_MAX_BYTES) || (NULL == p_handle))
    {
        return RM_SFD_ERR_INVALID_ARGUMENT;
    }
#endif

    index = rm_sfd_find_label(p_label, label_length);
    if (index < 0)
    {
        *p_handle = RM_SFD_HANDLE_INVALID;
        return RM_SFD_ERR_NOT_FOUND;
    }
    *p_handle = g_rm_sfd_ctrl.image.descriptors[index].handle;
    return RM_SFD_SUCCESS;
}

rm_sfd_err_t RM_SFD_GetObjectValue(rm_sfd_handle_t handle,
                                   uint8_t * p_data,
                                   uint32_t * p_data_length)
{
    int32_t index;
    rm_sfd_descriptor_t const * p_desc;

    if (0u == g_rm_sfd_ctrl.opened)
    {
        return RM_SFD_ERR_NOT_OPEN;
    }
#if (RM_SFD_CFG_PARAM_CHECKING_ENABLE)
    if (NULL == p_data_length)
    {
        return RM_SFD_ERR_INVALID_ARGUMENT;
    }
#endif

    index = rm_sfd_find_handle(handle);
    if (index < 0)
    {
        return RM_SFD_ERR_NOT_FOUND;
    }

    p_desc = &g_rm_sfd_ctrl.image.descriptors[index];
    if ((NULL == p_data) || (*p_data_length < p_desc->data_length))
    {
        *p_data_length = p_desc->data_length;
        return RM_SFD_ERR_NO_SPACE;
    }

    memcpy(p_data, &g_rm_sfd_ctrl.image.storage[p_desc->storage_offset], p_desc->data_length);
    *p_data_length = p_desc->data_length;
    return RM_SFD_SUCCESS;
}

rm_sfd_err_t RM_SFD_DeleteObject(rm_sfd_handle_t handle)
{
    int32_t index;
    rm_sfd_err_t err;
    uint32_t close_flash_on_exit = 0u;

    if (0u == g_rm_sfd_ctrl.opened)
    {
        return RM_SFD_ERR_NOT_OPEN;
    }

    index = rm_sfd_find_handle(handle);
    if (index < 0)
    {
        return RM_SFD_ERR_NOT_FOUND;
    }

    err = rm_sfd_repack_without(index, NULL, 0u, NULL, 0u, RM_SFD_HANDLE_INVALID);
    if (RM_SFD_SUCCESS != err)
    {
        return err;
    }

    if (FLASH_SUCCESS != rm_sfd_flash_open(&close_flash_on_exit))
    {
        return RM_SFD_ERR_FLASH;
    }
    err = rm_sfd_commit(1u - g_rm_sfd_ctrl.active_slot);
    rm_sfd_flash_close(close_flash_on_exit);
    return err;
}

rm_sfd_err_t RM_SFD_GetInfo(rm_sfd_info_t * p_info)
{
    if (0u == g_rm_sfd_ctrl.opened)
    {
        return RM_SFD_ERR_NOT_OPEN;
    }
#if (RM_SFD_CFG_PARAM_CHECKING_ENABLE)
    if (NULL == p_info)
    {
        return RM_SFD_ERR_INVALID_ARGUMENT;
    }
#endif

    p_info->base_address = g_rm_sfd_ctrl.base_address;
    p_info->region_size = g_rm_sfd_ctrl.region_size;
    p_info->slot_size = g_rm_sfd_ctrl.slot_size;
    p_info->used_bytes = rm_sfd_used_bytes();
    p_info->free_bytes = g_rm_sfd_ctrl.image.header.storage_size - p_info->used_bytes;
    p_info->object_count = rm_sfd_object_count();
    p_info->generation = g_rm_sfd_ctrl.image.header.generation;
    return RM_SFD_SUCCESS;
}

uint32_t RM_SFD_GetVersion(void)
{
    return (RM_SFD_RX_VERSION_MAJOR << 16) | RM_SFD_RX_VERSION_MINOR;
}

void RM_SFD_Zeroize(void * p_data, size_t length)
{
    volatile uint8_t * p = (volatile uint8_t *) p_data;
    while ((NULL != p) && (0u != length))
    {
        *p++ = 0u;
        length--;
    }
}

static uint32_t rm_sfd_crc32_update(uint32_t crc, uint8_t const * p_data, uint32_t length)
{
    uint32_t i;
    uint32_t bit;

    for (i = 0u; i < length; i++)
    {
        crc ^= p_data[i];
        for (bit = 0u; bit < 8u; bit++)
        {
            if (0u != (crc & 1u))
            {
                crc = (crc >> 1) ^ 0xedb88320u;
            }
            else
            {
                crc >>= 1;
            }
        }
    }
    return crc;
}

static uint32_t rm_sfd_crc32_finish(uint32_t crc)
{
    return crc ^ 0xffffffffu;
}

static uint32_t rm_sfd_image_crc(rm_sfd_slot_image_t const * p_image)
{
    uint32_t crc = 0xffffffffu;
    rm_sfd_slot_header_t header = p_image->header;
    header.crc32 = 0u;

    crc = rm_sfd_crc32_update(crc, (uint8_t const *) &header, (uint32_t) sizeof(header));
    crc = rm_sfd_crc32_update(crc, (uint8_t const *) p_image->descriptors, (uint32_t) sizeof(p_image->descriptors));
    crc = rm_sfd_crc32_update(crc, p_image->storage, (uint32_t) sizeof(p_image->storage));
    return rm_sfd_crc32_finish(crc);
}

static uint32_t rm_sfd_image_is_valid(rm_sfd_slot_image_t const * p_image, uint32_t slot_size)
{
    if ((RM_SFD_PERSISTENT_MAGIC != p_image->header.magic) ||
        (RM_SFD_PERSISTENT_SCHEMA_VERSION != p_image->header.version) ||
        (slot_size != p_image->header.slot_size) ||
        (RM_SFD_CFG_MAX_OBJECTS != p_image->header.object_count_max) ||
        (RM_SFD_STORAGE_SIZE != p_image->header.storage_size))
    {
        return 0u;
    }

    return (rm_sfd_image_crc(p_image) == p_image->header.crc32) ? 1u : 0u;
}

static void rm_sfd_image_init(rm_sfd_slot_image_t * p_image, uint32_t slot_size, uint32_t generation)
{
    memset(p_image, 0, sizeof(*p_image));
    p_image->header.magic = RM_SFD_PERSISTENT_MAGIC;
    p_image->header.version = RM_SFD_PERSISTENT_SCHEMA_VERSION;
    p_image->header.generation = generation;
    p_image->header.slot_size = slot_size;
    p_image->header.object_count_max = RM_SFD_CFG_MAX_OBJECTS;
    p_image->header.storage_size = RM_SFD_STORAGE_SIZE;
    p_image->header.crc32 = rm_sfd_image_crc(p_image);
}

static rm_sfd_err_t rm_sfd_read_slot(uint32_t slot, rm_sfd_slot_image_t * p_image)
{
    uint32_t address = g_rm_sfd_ctrl.base_address + (slot * g_rm_sfd_ctrl.slot_size);
    memset(p_image, 0, sizeof(*p_image));
    memcpy(p_image, (void const *) address, sizeof(*p_image));
    return RM_SFD_SUCCESS;
}

static rm_sfd_err_t rm_sfd_commit(uint32_t next_slot)
{
    g_rm_sfd_ctrl.image.header.generation++;
    g_rm_sfd_ctrl.image.header.crc32 = rm_sfd_image_crc(&g_rm_sfd_ctrl.image);
    return rm_sfd_flash_write_slot(next_slot, &g_rm_sfd_ctrl.image);
}

static rm_sfd_err_t rm_sfd_flash_wait_ready(void)
{
    flash_err_t err;
    do
    {
        err = R_FLASH_Control(FLASH_CMD_STATUS_GET, NULL);
    } while (FLASH_ERR_BUSY == err);

    return (FLASH_SUCCESS == err) ? RM_SFD_SUCCESS : RM_SFD_ERR_FLASH;
}

static rm_sfd_err_t rm_sfd_flash_write_slot(uint32_t slot, rm_sfd_slot_image_t const * p_image)
{
    uint32_t address = g_rm_sfd_ctrl.base_address + (slot * g_rm_sfd_ctrl.slot_size);
    uint32_t blocks = g_rm_sfd_ctrl.slot_size / FLASH_DF_BLOCK_SIZE;

    if (FLASH_SUCCESS != R_FLASH_Erase((flash_block_address_t) address, blocks))
    {
        return RM_SFD_ERR_FLASH;
    }
    if (RM_SFD_SUCCESS != rm_sfd_flash_wait_ready())
    {
        return RM_SFD_ERR_FLASH;
    }

    if (FLASH_SUCCESS != R_FLASH_Write((uint32_t) (uintptr_t) p_image, address, g_rm_sfd_ctrl.slot_size))
    {
        return RM_SFD_ERR_FLASH;
    }
    if (RM_SFD_SUCCESS != rm_sfd_flash_wait_ready())
    {
        return RM_SFD_ERR_FLASH;
    }

    g_rm_sfd_ctrl.active_slot = slot;
    return RM_SFD_SUCCESS;
}

static uint32_t rm_sfd_used_bytes(void)
{
    uint32_t used = 0u;
    uint32_t i;
    for (i = 0u; i < RM_SFD_CFG_MAX_OBJECTS; i++)
    {
        if (RM_SFD_DATA_STATUS_REGISTERED == g_rm_sfd_ctrl.image.descriptors[i].status)
        {
            used += g_rm_sfd_ctrl.image.descriptors[i].data_length;
        }
    }
    return used;
}

static uint32_t rm_sfd_object_count(void)
{
    uint32_t count = 0u;
    uint32_t i;
    for (i = 0u; i < RM_SFD_CFG_MAX_OBJECTS; i++)
    {
        if (RM_SFD_DATA_STATUS_REGISTERED == g_rm_sfd_ctrl.image.descriptors[i].status)
        {
            count++;
        }
    }
    return count;
}

static rm_sfd_handle_t rm_sfd_next_handle(void)
{
    uint32_t candidate;

    for (candidate = 0u; candidate < RM_SFD_CFG_MAX_OBJECTS; candidate++)
    {
        uint32_t used = 0u;
        uint32_t i;
        for (i = 0u; i < RM_SFD_CFG_MAX_OBJECTS; i++)
        {
            if ((RM_SFD_DATA_STATUS_REGISTERED == g_rm_sfd_ctrl.image.descriptors[i].status) &&
                (candidate == g_rm_sfd_ctrl.image.descriptors[i].handle))
            {
                used = 1u;
                break;
            }
        }
        if (0u == used)
        {
            return candidate;
        }
    }
    return RM_SFD_HANDLE_INVALID;
}

static int32_t rm_sfd_find_label(uint8_t const * p_label, uint32_t label_length)
{
    uint32_t i;
    for (i = 0u; i < RM_SFD_CFG_MAX_OBJECTS; i++)
    {
        rm_sfd_descriptor_t const * p_desc = &g_rm_sfd_ctrl.image.descriptors[i];
        if ((RM_SFD_DATA_STATUS_REGISTERED == p_desc->status) &&
            (label_length == p_desc->label_length) &&
            (0 == memcmp(p_desc->label, p_label, label_length)))
        {
            return (int32_t) i;
        }
    }
    return -1;
}

static int32_t rm_sfd_find_handle(rm_sfd_handle_t handle)
{
    uint32_t i;
    for (i = 0u; i < RM_SFD_CFG_MAX_OBJECTS; i++)
    {
        if ((RM_SFD_DATA_STATUS_REGISTERED == g_rm_sfd_ctrl.image.descriptors[i].status) &&
            (handle == g_rm_sfd_ctrl.image.descriptors[i].handle))
        {
            return (int32_t) i;
        }
    }
    return -1;
}

static rm_sfd_err_t rm_sfd_repack_without(int32_t skip_index,
                                          uint8_t const * p_new_label,
                                          uint32_t new_label_length,
                                          uint8_t const * p_new_data,
                                          uint32_t new_data_length,
                                          rm_sfd_handle_t new_handle)
{
    rm_sfd_slot_image_t * p_next = &g_rm_sfd_next_slot;
    uint32_t storage_offset = 0u;
    uint32_t desc_index = 0u;
    uint32_t i;

    rm_sfd_image_init(p_next, g_rm_sfd_ctrl.slot_size, g_rm_sfd_ctrl.image.header.generation);

    for (i = 0u; i < RM_SFD_CFG_MAX_OBJECTS; i++)
    {
        rm_sfd_descriptor_t const * p_src = &g_rm_sfd_ctrl.image.descriptors[i];
        if ((RM_SFD_DATA_STATUS_REGISTERED != p_src->status) || ((int32_t) i == skip_index))
        {
            continue;
        }
        if ((storage_offset + p_src->data_length) > RM_SFD_STORAGE_SIZE)
        {
            return RM_SFD_ERR_CORRUPT;
        }
        p_next->descriptors[desc_index] = *p_src;
        p_next->descriptors[desc_index].storage_offset = storage_offset;
        memcpy(&p_next->storage[storage_offset], &g_rm_sfd_ctrl.image.storage[p_src->storage_offset], p_src->data_length);
        storage_offset += p_src->data_length;
        desc_index++;
    }

    if (NULL != p_new_label)
    {
        if ((desc_index >= RM_SFD_CFG_MAX_OBJECTS) || ((storage_offset + new_data_length) > RM_SFD_STORAGE_SIZE))
        {
            return RM_SFD_ERR_NO_SPACE;
        }
        p_next->descriptors[desc_index].label_length = new_label_length;
        memcpy(p_next->descriptors[desc_index].label, p_new_label, new_label_length);
        p_next->descriptors[desc_index].storage_offset = storage_offset;
        p_next->descriptors[desc_index].data_length = new_data_length;
        p_next->descriptors[desc_index].status = RM_SFD_DATA_STATUS_REGISTERED;
        p_next->descriptors[desc_index].handle = new_handle;
        if (0u != new_data_length)
        {
            memcpy(&p_next->storage[storage_offset], p_new_data, new_data_length);
        }
    }

    p_next->header.crc32 = rm_sfd_image_crc(p_next);
    memcpy(&g_rm_sfd_ctrl.image, p_next, sizeof(g_rm_sfd_ctrl.image));
    return RM_SFD_SUCCESS;
}

static flash_err_t rm_sfd_flash_open(uint32_t * p_close_on_exit)
{
    flash_err_t err = R_FLASH_Open();
    *p_close_on_exit = 0u;
    if (FLASH_ERR_ALREADY_OPEN == err)
    {
        return FLASH_SUCCESS;
    }
    if (FLASH_SUCCESS == err)
    {
        *p_close_on_exit = 1u;
    }
    return err;
}

static void rm_sfd_flash_close(uint32_t close_on_exit)
{
    if (0u != close_on_exit)
    {
        (void) R_FLASH_Close();
    }
}
