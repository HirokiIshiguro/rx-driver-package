/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
#ifndef RM_SFD_RX_IF_H
#define RM_SFD_RX_IF_H

#include <stdint.h>
#include <stddef.h>
#include "rm_sfd_rx_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RM_SFD_RX_VERSION_MAJOR             (1u)
#define RM_SFD_RX_VERSION_MINOR             (0u)

/*
 * Persistent format compatibility policy:
 * - RM_SFD_PERSISTENT_MAGIC separates rm_sfd_rx slots from other middleware formats.
 * - RM_SFD_PERSISTENT_SCHEMA_VERSION is incremented only when the on-flash slot header, descriptor layout,
 *   object packing order, or integrity field semantics change.
 * - Bootloader and application images that share one data flash region must use the same schema version and the same
 *   rm_sfd_rx_config.h values. The runtime base address and region size passed to RM_SFD_Open() must also match.
 * - Version 1 uses two copy-on-write slots with CRC32 integrity. It is not an authenticity/MAC mechanism.
 */
#define RM_SFD_PERSISTENT_MAGIC             (0x44534652u)
#define RM_SFD_PERSISTENT_SCHEMA_VERSION    (1u)

#define RM_SFD_HANDLE_INVALID               (0xffffffffu)

typedef uint32_t rm_sfd_handle_t;

typedef enum e_rm_sfd_err
{
    RM_SFD_SUCCESS = 0,
    RM_SFD_ERR_INVALID_ARGUMENT,
    RM_SFD_ERR_NOT_OPEN,
    RM_SFD_ERR_NOT_FOUND,
    RM_SFD_ERR_NO_SPACE,
    RM_SFD_ERR_FLASH,
    RM_SFD_ERR_CORRUPT,
    RM_SFD_ERR_BUSY
} rm_sfd_err_t;

typedef struct st_rm_sfd_cfg
{
    uint32_t base_address;
    uint32_t region_size;
} rm_sfd_cfg_t;

typedef struct st_rm_sfd_info
{
    uint32_t base_address;
    uint32_t region_size;
    uint32_t slot_size;
    uint32_t used_bytes;
    uint32_t free_bytes;
    uint32_t object_count;
    uint32_t generation;
} rm_sfd_info_t;

rm_sfd_err_t RM_SFD_Open(rm_sfd_cfg_t const * p_cfg);
rm_sfd_err_t RM_SFD_Close(void);
rm_sfd_err_t RM_SFD_Format(void);
rm_sfd_err_t RM_SFD_SaveObject(uint8_t const * p_label,
                               uint32_t label_length,
                               uint8_t const * p_data,
                               uint32_t data_length,
                               rm_sfd_handle_t * p_handle);
rm_sfd_err_t RM_SFD_FindObject(uint8_t const * p_label,
                               uint32_t label_length,
                               rm_sfd_handle_t * p_handle);
rm_sfd_err_t RM_SFD_GetObjectValue(rm_sfd_handle_t handle,
                                   uint8_t * p_data,
                                   uint32_t * p_data_length);
rm_sfd_err_t RM_SFD_DeleteObject(rm_sfd_handle_t handle);
rm_sfd_err_t RM_SFD_GetInfo(rm_sfd_info_t * p_info);
uint32_t RM_SFD_GetVersion(void);
void RM_SFD_Zeroize(void * p_data, size_t length);

#ifdef __cplusplus
}
#endif

#endif /* RM_SFD_RX_IF_H */
