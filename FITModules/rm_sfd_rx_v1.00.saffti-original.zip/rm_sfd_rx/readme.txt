rm_sfd_rx: small shared data-flash key/value store for Renesas RX.

