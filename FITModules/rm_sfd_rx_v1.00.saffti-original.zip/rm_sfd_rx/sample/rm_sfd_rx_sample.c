/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
#include <stdint.h>
#include <string.h>

#include "r_flash_rx_if.h"
#include "rm_sfd_rx_if.h"

void rm_sfd_rx_sample(void)
{
    static uint8_t const label[] = "tsip:key-index";
    static uint8_t const value[] = { 0x01u, 0x02u, 0x03u, 0x04u };
    uint8_t read_buffer[16];
    uint32_t read_length = sizeof(read_buffer);
    rm_sfd_handle_t handle = RM_SFD_HANDLE_INVALID;
    rm_sfd_cfg_t cfg;

    cfg.base_address = (uint32_t) FLASH_DF_BLOCK_0;
    cfg.region_size = RM_SFD_CFG_REGION_SIZE_BYTES;

    if (RM_SFD_SUCCESS != RM_SFD_Open(&cfg))
    {
        return;
    }

    if (RM_SFD_SUCCESS == RM_SFD_SaveObject(label, (uint32_t) (sizeof(label) - 1u), value, sizeof(value), &handle))
    {
        (void) RM_SFD_GetObjectValue(handle, read_buffer, &read_length);
    }

    RM_SFD_Zeroize(read_buffer, sizeof(read_buffer));
    (void) RM_SFD_Close();
}

