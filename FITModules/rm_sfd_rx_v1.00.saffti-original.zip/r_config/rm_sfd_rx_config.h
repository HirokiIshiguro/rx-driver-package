/***********************************************************************************************************************
* Copyright (c) 2026 SAFFTI (Smart Agriculture, Forestry & Fisheries Technology Institute) and contributors
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
#ifndef RM_SFD_RX_CONFIG_H
#define RM_SFD_RX_CONFIG_H

/* Total data flash region size used by default examples. RM_SFD_Open() still receives the actual size at runtime. */
#define RM_SFD_CFG_REGION_SIZE_BYTES        (32768u)

/* The region is split into two slots, so the slot size is half of the region size. */
#define RM_SFD_CFG_SLOT_SIZE_BYTES          (RM_SFD_CFG_REGION_SIZE_BYTES / 2u)

#define RM_SFD_CFG_MAX_OBJECTS              (20u)
#define RM_SFD_CFG_LABEL_MAX_BYTES          (40u)

/* Set to 1 to include API parameter checking. */
#define RM_SFD_CFG_PARAM_CHECKING_ENABLE    (1u)

/* Optional debug hook. */
#define RM_SFD_CFG_DEBUG_LOG_ENABLE         (0u)
#define RM_SFD_CFG_DEBUG_PRINTF(x)          ((void)0)

#endif /* RM_SFD_RX_CONFIG_H */

