# r_sdio_rx

`r_sdio_rx` provides SDIO protocol helpers above an application-supplied host
driver. The host driver must issue CMD52 and CMD53 transfers through callbacks.

The first release focuses on the path needed by SDIO Wi-Fi bring-up:

- CMD52 read/write wrappers.
- CMD53 byte/block read/write wrappers.
- CCCR/FBR/CIS helpers.
- Function enable and IO_READY polling.
- Interrupt enable/pending register helpers.
- Broadcom/Infineon backplane-window helpers.

## Host callback contract

The host callbacks are responsible for controller-specific command issue and
data phase handling. They must store the raw R5 response in the request
structure and return `SDIO_SUCCESS` only after the transfer is complete enough
for the protocol layer to continue.

For CMD53 write transfers, the host must feed the payload without reading from
the host data port. On RX SDHI, the EK-RX671 Type 1YN bring-up used the real
`SDBUFR` address obtained from `R_SDHI_GetBuffRegAddress()`, volatile word
writes, and normal `SDSTS1.ACEND` data completion. It did not use register
helpers that read `SDBUFR` back during the write phase, and it did not use
`SDSTOP.STP` as the normal success path.

The module does not contain WICED source and does not depend on WICED headers.
