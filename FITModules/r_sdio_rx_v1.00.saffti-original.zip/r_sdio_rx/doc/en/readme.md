# r_sdio_rx

`r_sdio_rx` provides SDIO protocol helpers above an application-supplied host
driver. The host driver must issue CMD52 and CMD53 transfers through callbacks.

The first release focuses on the path needed by SDIO Wi-Fi bring-up:

- CMD52 read/write wrappers.
- CMD53 byte/block read/write wrappers.
- CCCR/FBR/CIS helpers.
- Function enable and IO_READY polling.
- Interrupt enable/pending register helpers.
- Broadcom/Infineon backplane-window helpers.

The module does not contain WICED source and does not depend on WICED headers.
