# r_sdio_rx

`r_sdio_rx` は、アプリケーションが提供する SDIO ホストドライバの上に載せる
SDIO プロトコル補助モジュールです。下位ホストはコールバックを通じて CMD52 と
CMD53 を発行します。

初期版では SDIO Wi-Fi 立ち上げに必要な次の範囲を扱います。

- CMD52 read/write ラッパ
- CMD53 byte/block read/write ラッパ
- CCCR/FBR/CIS 補助関数
- Function enable と IO_READY polling
- Interrupt enable/pending レジスタ補助関数
- Broadcom/Infineon backplane-window 補助関数

WICED ソースコードや WICED ヘッダには依存しません。
