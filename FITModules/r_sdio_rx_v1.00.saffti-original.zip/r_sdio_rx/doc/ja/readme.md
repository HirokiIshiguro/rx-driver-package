# r_sdio_rx

`r_sdio_rx` は、アプリケーションが提供する SDIO ホストドライバの上に載せる
SDIO プロトコル補助モジュールです。下位ホストはコールバックを通じて CMD52 と
CMD53 を発行します。

初期版では SDIO Wi-Fi 立ち上げに必要な次の範囲を扱います。

- CMD52 read/write ラッパ
- CMD53 byte/block read/write ラッパ
- CCCR/FBR/CIS 補助関数
- Function enable と IO_READY polling
- Interrupt enable/pending レジスタ補助関数
- Broadcom/Infineon backplane-window 補助関数

## ホストコールバック契約

ホストコールバックは、コントローラ固有のコマンド発行とデータフェーズ処理を担当します。
生の R5 応答を要求構造体へ格納し、プロトコル層が次へ進めるところまで転送が完了して
から `SDIO_SUCCESS` を返してください。

CMD53 write では、ホストのデータポートを読み戻さずにペイロードを書き込む必要があります。
EK-RX671 + Type 1YN の RX SDHI 立ち上げでは、`R_SDHI_GetBuffRegAddress()` で取得した
実 SDBUFR アドレスへ volatile word write し、通常の `SDSTS1.ACEND` データ完了を待つ
ことで安定しました。write フェーズ中に `SDBUFR` を読み戻すレジスタヘルパと、
通常成功パスとしての `SDSTOP.STP` は使いません。

WICED ソースコードや WICED ヘッダには依存しません。
