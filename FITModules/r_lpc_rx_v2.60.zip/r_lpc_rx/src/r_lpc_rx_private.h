/***********************************************************************************************************************
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name    : r_lpc_rx_private.h
 * Version      : 2.51
 * Description  : The LPC module configures the MCU for the different operating and low power modes.
 *                This file is the LPC module's interface header file and should be included by the application that
 *                intends to use the API.
 ************************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *           01.10.2016 1.0     Initial Release
 *           31.07.2021 2.03    Add lpc_snooze_mode_configure() function declaration for rx140
 *           31.12.2021 2.04    Delete lpc_operating_mode_set() and lpc_return_clock_switch()
 *                              function declaration for rx660.
 *           29.05.2023 2.30    Fixed to comply with GSCE Coding Standards Rev.6.5.0.
 *           28.06.2024 2.40    Fixed to comply with GSCE Coding Standards Rev.6.5.0.
 *           15.03.2025 2.51    Updated disclaimer.
 *           30.10.2025 2.60    Added support for RX14T.
 ***********************************************************************************************************************/
#ifndef R_LPC_RX_PRIVATE_H
    #define R_LPC_RX_PRIVATE_H

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/

/***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/

/***********************************************************************************************************************
 Typedef definitions
 ***********************************************************************************************************************/

/***********************************************************************************************************************
 Public Functions
 ***********************************************************************************************************************/
#ifndef LPC_INVALID_OPERATING_MODE
/**********************************************************************************************************************
 * Function Name: lpc_operating_mode_set
 * Description  : .
 * Argument     : e_mode
 * Return Value : .
 *********************************************************************************************************************/
lpc_err_t lpc_operating_mode_set (lpc_operating_mode_t e_mode);
#endif
/**********************************************************************************************************************
 * Function Name: lpc_low_power_mode_configure
 * Description  : .
 * Argument     : e_mode
 * Return Value : .
 *********************************************************************************************************************/
lpc_err_t lpc_low_power_mode_configure (lpc_low_power_mode_t e_mode);

/**********************************************************************************************************************
 * Function Name: lpc_lowpower_activate
 * Description  : .
 * Argument     : pcallback
 * Return Value : .
 *********************************************************************************************************************/
lpc_err_t lpc_lowpower_activate (lpc_callback_set_t pcallback);

#ifndef BSP_MCU_RX14T
/**********************************************************************************************************************
 * Function Name: lpc_return_clock_switch
 * Description  : .
 * Arguments    : e_clock_source
 *              : enable
 * Return Value : .
 *********************************************************************************************************************/
lpc_err_t lpc_return_clock_switch (lpc_clock_switch_t e_clock_source, bool enable);
#endif /* BSP_MCU_RX14T */

#ifdef LPC_VALID_SNOOZE_MODE
/**********************************************************************************************************************
 * Function Name: lpc_snooze_mode_configure
 * Description  : .
 * Arguments    : snooze_mode
 * Return Value : .
 *********************************************************************************************************************/
lpc_err_t lpc_snooze_mode_configure (lpc_snooze_mode_t * snooze_mode);
#endif
#endif /* R_LPC_RX_PRIVATE_H */
/***********************************************************************************************************************
 * End of File
 ***********************************************************************************************************************/
